<?php
header("location: user/user.login.php");

?>