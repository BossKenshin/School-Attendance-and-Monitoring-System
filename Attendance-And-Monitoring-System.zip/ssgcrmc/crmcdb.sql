-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2023 at 08:39 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crmcdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `user_image` varchar(255) DEFAULT NULL,
  `position` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fullname`, `email`, `user_image`, `position`, `password`) VALUES
(1, 'Drenz Pianar', 'drenz@gmail.com', 'deer-animal-background-ai-art-4k-wallpaper-uhdpaper.com-24@0@i.jpg', 'President', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `category_list`
--

CREATE TABLE `category_list` (
  `id` int(30) NOT NULL,
  `category` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category_list`
--

INSERT INTO `category_list` (`id`, `category`) VALUES
(1, 'President'),
(2, 'Vice President'),
(3, 'Secretary'),
(4, 'Treasurer'),
(5, 'Auditor'),
(6, 'Public Information Officer'),
(7, 'Peace Officer'),
(8, 'First Year Representative'),
(9, 'Second Year Representative'),
(10, 'Third Year Representative'),
(11, 'Fourth Year Representative');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `Id` int(11) NOT NULL,
  `What` varchar(255) NOT NULL,
  `Where` varchar(255) NOT NULL,
  `When` date NOT NULL,
  `timein` varchar(255) NOT NULL,
  `timeout` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active',
  `longi` varchar(255) NOT NULL,
  `lati` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`Id`, `What`, `Where`, `When`, `timein`, `timeout`, `img`, `status`, `longi`, `lati`) VALUES
(1, 'Meeting', 'Gairan', '2023-07-02', '01:49', '14:49', 'moon.png', 'Inactive', '124.036809', '11.028977'),
(2, '   SSG Nite', 'CRMC', '2023-07-02', '02:11', '14:01', 'bvg.jpg', 'Active', '       124.005039', '       11.049636'),
(3, 'Ligo Dagat', 'Secret Paradise', '2023-07-02', '02:25', '14:29', 'wallpaperflare.com_wallpaper (1).jpg', 'Active', '124.036818', '11.029009');

-- --------------------------------------------------------

--
-- Table structure for table `event_attendance`
--

CREATE TABLE `event_attendance` (
  `Id` int(11) NOT NULL,
  `student_Id` int(255) NOT NULL,
  `event_Id` int(255) NOT NULL,
  `Status` varchar(255) NOT NULL DEFAULT 'Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_attendance`
--

INSERT INTO `event_attendance` (`Id`, `student_Id`, `event_Id`, `Status`) VALUES
(1, 1, 1, 'Inactive'),
(2, 2, 1, 'Active'),
(3, 3, 1, 'Inactive'),
(4, 4, 1, 'Inactive'),
(5, 1, 2, 'Inactive'),
(6, 2, 2, 'Inactive'),
(7, 3, 2, 'Inactive'),
(8, 4, 2, 'Inactive'),
(9, 1, 3, 'Active'),
(10, 2, 3, 'Inactive'),
(11, 3, 3, 'Inactive'),
(12, 4, 3, 'Inactive');

-- --------------------------------------------------------

--
-- Table structure for table `event_penalty`
--

CREATE TABLE `event_penalty` (
  `Id` int(11) NOT NULL,
  `student_Id` int(255) NOT NULL,
  `event_Id` int(255) NOT NULL,
  `penalty` decimal(10,0) NOT NULL,
  `Status` varchar(255) NOT NULL DEFAULT 'Unpaid'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_penalty`
--

INSERT INTO `event_penalty` (`Id`, `student_Id`, `event_Id`, `penalty`, `Status`) VALUES
(1, 1, 1, 150, 'Paid'),
(2, 3, 1, 150, 'Paid'),
(3, 4, 1, 150, 'Unpaid');

-- --------------------------------------------------------

--
-- Table structure for table `onlinepayment`
--

CREATE TABLE `onlinepayment` (
  `pay_id` int(11) NOT NULL,
  `stid` int(11) NOT NULL,
  `penaltyid` int(11) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `pay_status` varchar(11) NOT NULL DEFAULT 'unpaid'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `onlinepayment`
--

INSERT INTO `onlinepayment` (`pay_id`, `stid`, `penaltyid`, `amount`, `image`, `pay_status`) VALUES
(2, 3, 2, '150', 'df.PNG', 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `stid` int(11) NOT NULL,
  `student_id_no` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `course_year` varchar(255) NOT NULL,
  `st_username` varchar(50) NOT NULL,
  `st_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`stid`, `student_id_no`, `firstname`, `lastname`, `email`, `gender`, `course_year`, `st_username`, `st_password`) VALUES
(1, '357567', 'Drenz', 'Pianar', 'noob@gmail.com', 'Male', 'BSIT 2nd Year', 'nEat2397', 'user'),
(2, '15546556', 'Kobe', 'Biran', 'mamba@gmail.com', 'Male', 'BSIT 3rd Year', 'pgxoc2Ey', 'user1'),
(3, '12315415', 'Michael', 'Jordan', 'goat@gmail.com', 'Male', 'BSIT 2nd Year', 'LZEEay9Z', 'user2'),
(4, '15546556', 'Nobito', 'Rimuru', 'nuub@gmail.com', 'Male', 'BSIT 3rd Year', 'nQmlyeCp', 'user3');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `id` int(30) NOT NULL,
  `category_id` int(30) NOT NULL,
  `voting_opt_id` int(30) NOT NULL,
  `stid` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `category_id`, `voting_opt_id`, `stid`) VALUES
(1, 1, 1, 1),
(2, 2, 3, 1),
(3, 3, 4, 1),
(4, 4, 5, 1),
(5, 5, 6, 1),
(6, 6, 7, 1),
(7, 7, 8, 1),
(8, 8, 9, 1),
(9, 9, 10, 1),
(10, 10, 11, 1),
(11, 11, 12, 1);

-- --------------------------------------------------------

--
-- Table structure for table `voting_cat_settings`
--

CREATE TABLE `voting_cat_settings` (
  `id` int(30) NOT NULL,
  `voting_id` int(30) NOT NULL,
  `category_id` int(30) NOT NULL,
  `max_selection` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `voting_list`
--

CREATE TABLE `voting_list` (
  `id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `is_default` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `voting_opt`
--

CREATE TABLE `voting_opt` (
  `id` int(30) NOT NULL,
  `category_id` int(30) NOT NULL,
  `image_path` text NOT NULL,
  `Name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `voting_opt`
--

INSERT INTO `voting_opt` (`id`, `category_id`, `image_path`, `Name`) VALUES
(1, 1, 'main-qimg-36aebf7b6d4be564d3275a9ec592c0e9-lq.jfif', 'Candice Chow'),
(2, 1, 'car.jpg', 'Ferb Chow'),
(3, 2, 'wallpaperflare.com_wallpaper (1).jpg', 'Bog Bog'),
(4, 3, 'hppy.png', 'sec1'),
(5, 4, 'moon.png', 'tre1'),
(6, 5, 'df.PNG', 'aud1'),
(7, 6, 'moon.png', 'pio1'),
(8, 7, 'moon.png', 'po1'),
(9, 8, 'deer-animal-background-ai-art-4k-wallpaper-uhdpaper.com-24@0@i.jpg', 'f1'),
(10, 9, 'hppy.png', 'f2'),
(11, 10, 'moon.png', 'f3'),
(12, 11, 'hppy.png', 'f4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_list`
--
ALTER TABLE `category_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `event_attendance`
--
ALTER TABLE `event_attendance`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `event_penalty`
--
ALTER TABLE `event_penalty`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `onlinepayment`
--
ALTER TABLE `onlinepayment`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`stid`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voting_cat_settings`
--
ALTER TABLE `voting_cat_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voting_list`
--
ALTER TABLE `voting_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voting_opt`
--
ALTER TABLE `voting_opt`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `category_list`
--
ALTER TABLE `category_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `event_attendance`
--
ALTER TABLE `event_attendance`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `event_penalty`
--
ALTER TABLE `event_penalty`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `onlinepayment`
--
ALTER TABLE `onlinepayment`
  MODIFY `pay_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `stid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `voting_cat_settings`
--
ALTER TABLE `voting_cat_settings`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `voting_list`
--
ALTER TABLE `voting_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `voting_opt`
--
ALTER TABLE `voting_opt`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
