<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <title> CRMC SSG </title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg" />
    <link rel="stylesheet" href="adminstyles.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.2/xlsx.full.min.js"
        integrity="sha512-qilAGdDSZ5c0sTjizcSCffmIb8D2rHttMYGUxtI3OFn8lB29BlU2tEUcPesHHLQ2t0Y5TInglWKY6V3GoSK0IA=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

    <?php

    include './fragments/sidebar.php';
    ?>


    <section class="home-section">
        <nav>
            <div class="sidebar-button">
                <i class='il uil-arrow-circle-left sidebarBtn'></i>

            </div>

       

            <div class="profile-details">

                <i class="uil uil-user-circle"></i>
                <i class="bx bx-chevron-down" onclick="toggleMenu()"></i>

                <div class="sub-menu-wrap" id="subMenu">
                    <div class="sub-menu">
                        <div class="user-info">
                            <i class="uil uil-user-circle user"></i>
                            <h6>Admin Account</h6>
                            <hr>
                        </div>


                        <a href="#" class="sub-menu-link">
                            <i class="il uil-user-square usermenu"></i>
                            <p>Profile</p>
                        </a>
                        <a href="#" class="sub-menu-link">
                            <i class="uil uil-signout usermenu"></i>
                            <p>Log Out</p>
                        </a>

                    </div>
                </div>

            </div>
        </nav>

        <div class="home-content">
            <div class="dashboard">
                <br>
            </div>
            <br><br>

        


                <div class="con">
                    <i class="uil uil-sign-alt"></i>
                    <h3>Voting Categories</h3>
                </div>

                <div class="containers py-5"
                    style="width:1300px; height:400px; font-size: 13px; overflow-y: scroll; overflow-x:scroll; max-height:100vh">
                    <div class="row">

                        <table id="example" class="table table-striped" style="width:100%">
                            <thead style="color: black; background: #6237A0; font-weight:1000px;">
                                <tr>
                                    <th style="text-align: center"><b>ID</b></th>
                                    <th style="text-align: center"><b>STUDENT NAME</b></th>
                                    <th style="text-align: center"><b>POSITION</b></th>
                                    <th style="text-align: center"><b>NUMBER OF VOTES</b></th>

                                </tr>
                            </thead>
                            <tbody>
                                <style>
                                    td {
                                        text-align: left;
                                    }
                                </style>
                                <!-- <tr>

                                    </tr>
-->

                            </tbody>

                        </table>
                    </div>
                </div>
    </section>


    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>


</body>

</html>