<?php
include "header.html"

  ?>
<?php

include './fragments/sidebar.php';
?>
<section class="home-section">
  <nav>
    <div class="sidebar-button">
      <i class="il uil-arrow-circle-left sidebarBtn"></i>
    </div>

    <div class="profile-details">
      <i class="uil uil-user-circle"></i>
      <i class="bx bx-chevron-down" onclick="toggleMenu()"></i>

      <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
          <div class="user-info">
            <i class="uil uil-user-circle user"></i>
            <h4>Admin Account</h4>
            <hr>
          </div>


          <a href="#" class="sub-menu-link">
            <i class="il uil-user-square usermenu"></i>
            <p>Profile</p>
          </a>
          <a href="logout.php" class="sub-menu-link">
            <i class="uil uil-signout usermenu"></i>
            <p>Log Out</p>
          </a>

        </div>
      </div>
    </div>
  </nav>

  <div class="home-content">
    <div class="overview-boxes">

      <div class="con">
        <i class="uil uil-notebooks"></i>
        <h3>Create School Events</h3>
      </div>
      <div class="containers py-5 aos-init aos-animate" style="width:1300px" data-aos="fade-up">
        <section id="book-a-table" class="book-a-table">
          <div class="row g-0">

            <div class="col-lg-4 col-md-6 reservation-img" id="pic" style="background-image: url(images/photo.png)"
              data-aos="zoom-out" data-aos-delay="200"></div>

            <input type="file" name="file" onchange="changeBackgroundImage(event)" id="pics" style="display:none;"
              accept="image/*" required />
            <div class="col-lg-8 d-flex align-items-center reservation-form-bg">
              <form action="#" method="post" autocomplete="off" class="add-form" data-aos="fade-up"
                data-aos-delay="100">
                <div class="row gy-4">
                  <div class="col-lg-10 col-md-6">
                    <input type="text" name="what" class="form-control" id="what" placeholder="WHAT:" required />

                  </div>
                  <div class="col-lg-10 col-md-6">
                    <input type="text" class="form-control" name="where" id="where" placeholder="WHERE:" required />

                  </div>
                  <div class="col-lg-10 col-md-6">
                    <input name="date" type="text" class="form-control" id="when" placeholder="WHEN:"
                      onfocus="(this.type='date')" />

                  </div>

                  <div class="col-lg-10 col-md-6">

                    <input type="time" class="form-control" name="timestart" id="timestart" placeholder="Sign in"
                      required>
                    <br>
                    <input type="time" class="form-control" name="timeout" id="timeout" placeholder="Sign out" required>
                  </div>
                  <div class="col-lg-10 col-md-6">
                    <p class="text-center">Input the Latitude and Longitude where the event will happen below.</p>

                    <input type="text" class="form-control" name="latitude" id="latitude" placeholder="Latitude 11.1245"
                      required>
                    <br>
                    <input type="text" class="form-control" name="longitude" id="longitude"
                      placeholder="Longitude 124.12345" required>
                  </div>
                </div>
                <div class="form-group mt-3">


                </div>
              </form>



            </div>
            <div style="position: relative; display: flex;justify-content:right;margin-top: 10px;"><button type="button"
                class="btn btn-outline-warning  uil uil-plus" style="background-Color:#66db93;Color:black;"
                id="submit">Create Event</button></div>
          </div>


        </section>
      </div>
    </div>
  </div>
</section>
<script>

  $("#submit").click(function () {

    var up = $("#pics").val().length;
    var pic;
    if (up > '0') {
     pic = $('#pics').val().replace(/.*(\/|\\)/, '');
    }
    else {
       pic = '0';
    }

    console.log(pic);
    
    var What = document.querySelector("#what").value;
    var Where = document.querySelector("#where").value;
    var When = document.querySelector("#when").value;
    var tin = document.querySelector("#timestart").value;
    var tout = document.querySelector("#timeout").value;
    var lat = document.querySelector("#latitude").value;
    var lon = document.querySelector("#longitude").value;

    Swal.fire({ title: 'Do you really want to Add this event?', showDenyButton: true, confirmButtonText: 'Yes', denyButtonText: `No`, })
      .then((result) => {
        if (result.isConfirmed && What != "" && Where != "" && When != "" & tin != "" && tout != "" && lat != "" && lon != "") {
          // send data to server
          $.ajax({
            url: "sql/event.create.php",
            type: "GET",
            data: {
              what: What,
              where: Where,
              when: When,
              timein: tin,
              timeout: tout,
              latitude: lat,
              longitude: lon,
              Pic: pic

            }
          })
            .done(function (data) {
              let result = JSON.parse(data);
              if (result.res == "success") {
                      $.ajax({
                    url  : "sql/add.event.student.php",
                    type : "GET",
                    data :  {
                    what :What,
                    }
                })
                .done(function(data){
                  let result = JSON.parse(data);
                    console.log(result.res);
                });
                uploadpic();

                    }else{
                        alert2("Error, Something happened");
                    }
                });
                Swal.fire('Events are successfully saved', '', 'success')
                document.querySelector("form").reset();
                const divElement = document.getElementById("pic");
                divElement.style.backgroundImage = "url(images/photo.png)";

              }
              else if (result.isDenied) {

                document.querySelector("form").reset();
                const divElement = document.getElementById("pic");
                divElement.style.backgroundImage = "url(images/photo.png)";

                Swal.fire('Events are not saved', '', 'info')
              }
              else {
                Swal.fire({
                  icon: 'error',
                  title: 'Empty',
                  text: 'Fill out the form to Add event',
                  showConfirmButton: true,
                  allowOutsideClick: true
                })
              }
            });

        });





    $("#pic").click(function () {
      document.querySelector("#pics").click();
    });

    function changeBackgroundImage(event) {
      const file = event.target.files[0];
      const reader = new FileReader();

      reader.onload = function (e) {
        const imageUrl = e.target.result;
        document.getElementById('pic').style.backgroundImage = `url(${imageUrl})`;
      }

      reader.readAsDataURL(file);

    };

    function uploadpic() {

      var file_data = $('#pics').prop('files')[0];
      var form_data = new FormData();
      form_data.append('file', file_data);
      $.ajax({
        url: 'sql/uploads.php',
        dataType: 'text',
        cache: false,
        contentType: false,
        processData: false,
        data: form_data,
        type: 'post',
        success: function (php_script_response) { }
      });
    };


</script>
<?php
include "footer.html"

  ?>