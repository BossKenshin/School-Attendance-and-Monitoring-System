
<?php
include './sql/dbconnect.php';


extract($_POST); 
  if(isset($_POST['catSend']) && isset( $_FILE['imgSend']) && isset($_POST['canSend'])   ) {
    
     $query="INSERT INTO voting_opt (category_id,image_path, Name) VALUES 
     ('$catSend','$imgSend','$canSend')";
       $result = mysqli_query($conn,$query);
  }

 


?>