<?php
include "header.html"

    ?>

<?php

include './fragments/sidebar.php';
?>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-2" id="exampleModalLabel">Add Candidate</h1>
            </div>
            <div class="modal-body">
                <form>
                    <div class="form-group">


                        <label for="candidate-name" class="col-form-label">Candidate Name:</label>
                        <input type="text" class="form-control " name="candidate-name" id="candidatename">

                        <br>

                        <label for="position" class="col-form-label">Candidate Position:</label>

                        <select class="form-select form-select-lg mb-3 " aria-label="Default select example"
                            name="position" style="font-size: 18px;" id="candidateposition">
                            <option value="1">President</option>
                            <option value="2">Vice-President</option>
                            <option value="3">Secretary</option>
                            <option value="4">Treasurer</option>
                            <option value="5">Auditor</option>
                            <option value="6">Public Information Officer</option>
                            <option value="7">Peace Officer</option>
                            <option value="8">First Year Representative</option>
                            <option value="9">Second Year Representative</option>
                            <option value="10">Third Year Representative</option>
                            <option value="11">Fourth Year Representative</option>


                        </select>

                        <label for="candidate-pic" class="col-form-label">Candidate Pic:</label>

                        <input type="file" name="candidate-pic" id="candidatepic"
                            accept="image/png, image/gif, image/jpeg">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="submit" data-dismiss="modal">Save Changes</button>
            </div>
        </div>
    </div>
</div>



<div class="modal fade" id="editCandidateModal" tabindex="-1" aria-labelledby="editCandidateModal" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-2" id="editCandidateModal">Edit Candidate</h1>
            </div>
            <div class="modal-body">
                <form>
                    <div class="form-group">


                        <label for="candidate-name" class="col-form-label">Candidate Name:</label>
                        <input type="text" class="form-control " name="candidate-name" id="ecandidatename">

                        <br>

                        <label for="position" class="col-form-label">Candidate Position:</label>

                        <select class="form-select form-select-lg mb-3 " aria-label="Default select example"
                            name="position" style="font-size: 18px;" id="ecandidateposition">
                            <option value="1">President</option>
                            <option value="2">Vice-President</option>
                            <option value="3">Secretary</option>
                            <option value="4">Treasurer</option>
                            <option value="5">Auditor</option>
                            <option value="6">Public Information Officer</option>
                            <option value="7">Peace Officer</option>
                            <option value="8">First Year Representative</option>
                            <option value="9">Second Year Representative</option>
                            <option value="10">Third Year Representative</option>
                            <option value="11">Fourth Year Representative</option>
                        </select>

                        <label for="candidate-pic" class="col-form-label">Candidate Pic:</label>

                        <input type="file" name="candidate-pic" id="ecandidatepic"
                            accept="image/png, image/gif, image/jpeg">

                        <input type="hidden" name="catid" id="candidateid">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger" id="edelete" data-dismiss="modal">Delete Candidate</button>
                <button type="button" class="btn btn-primary" id="esubmit" data-dismiss="modal">Save Changes</button>
            </div>
        </div>
    </div>
</div>

<!-- -----------------------------MODAL---------------------------- -->

<!-- --------------------------------------------------------- -->

<section class="home-section">
    <nav>
        <div class="sidebar-button">
            <i class='il uil-arrow-circle-left sidebarBtn'></i>

        </div>

        <div class="profile-details">

            <i class="uil uil-user-circle"></i>
            <i class="bx bx-chevron-down" onclick="toggleMenu()"></i>

            <div class="sub-menu-wrap" id="subMenu">
                <div class="sub-menu">
                    <div class="user-info">
                        <i class="uil uil-user-circle user"></i>
                        <h6>Admin Account</h6>
                        <hr>
                    </div>


                    <a href="user_profile.php" class="sub-menu-link">
                        <i class="il uil-user-square usermenu"></i>
                        <p>Profile</p>
                    </a>
                    <a href="admin_logout.php" class="sub-menu-link">
                        <i class="uil uil-signout usermenu"></i>
                        <p>Log Out</p>
                    </a>

                </div>
            </div>

        </div>
    </nav>

    <div class="home-content">
        <div class="dashboard">
            <br>
        </div>
        <br><br>




        <div class="con">
            <i class="uil uil-sign-alt"></i>
            <h3>Manage Votings</h3>
        </div>
        <button type="button" id="penal" class="btn btn-success m-4 uil uil-plus" data-toggle="modal"
            data-target="#exampleModal" style="  background-color: #66db93;"><a href="#"
                style="Color:black; text-decoration: none">Add Candidate</a></button>

        <div class="containers py-5"
            style="width:1300px; height:400px; font-size: 13px; overflow-y: scroll; overflow-x:scroll; max-height:100vh">
            <div class="row">

                <table id="example" class="table table-striped" style="width:100%">
                    <thead style="color: black; background: #6237A0; font-weight:1000px;">
                        <tr>
                            <th style=" visibility:hidden;"><b>ID</b></th>
                            <th style="text-align: center"><b>STUDENT NAME</b></th>
                            <th style="text-align: center"><b>POSITION</b></th>

                        </tr>
                    </thead>
                    <tbody>
                        <style>
                            td {
                                text-align: left;
                            }
                        </style>
                        <tr>
                            <?php
                            include './sql/dbconnect.php';

                            $sql = "SELECT voting_opt.id as cid, category_list.category as post,category_list.id as caid, Name  FROM voting_opt 
                            INNER JOIN category_list ON voting_opt.category_id = category_list.id
                            ORDER BY category_id ASC;";
                            $stmt = mysqli_query($conn, $sql);

                            while ($row = mysqli_fetch_object($stmt)) {
                                ?>

                                <td style="visibility:none;>" <?= $row->cid ?> </td>
                                <td>
                                    <?= $row->Name ?>
                                </td>
                                <td>
                                    <?= $row->post ?>
                                </td>
                                <td>
                                    <button class="btn btn-success edit" id="viewbtn" data-cid="<?php echo $row->cid ?>" ;
                                        data-toggle="modal" data-target="#editCandidateModal">Edit</button>

                                </td>
                            </tr>
                        <?php } ?>

                    </tbody>

                </table>
            </div>
        </div>
</section>

<script type="text/javascript">
    $("#submit").click(function () {

        var formdata = new FormData();

        var file = $('#candidatepic').prop('files')[0];

        var cname = $('#candidatename').val();
        var cposition = $('#candidateposition').find(":selected").val();



        if (file) {

            formdata.append('image', file);
            formdata.append('name', cname);
            formdata.append('position', cposition)

            $.ajax({
                url: "sql/add.candidate.php",
                type: "POST",
                data: formdata,
                processData: false,
                contentType: false,
            })
                .done(function (data) {

                    let result = JSON.parse(data);

                    if (result.res == "success") {


                        Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Candidate Updated',
                        timer: 2000,
                        showConfirmButton: false,
                        allowOutsideClick: false
                    }).then((result) => {
                    if (result.dismiss === Swal.DismissReason.timer) {
                        location.reload();
                    }
                    })
                    }
                    else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: 'Something went wrong',

                        })
                    }
                });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'No photo selected',

            })

        }


    });



    $("#esubmit").click(function () {

        var formdata = new FormData();

        var file = $('#ecandidatepic').prop('files')[0];

        var cname = $('#ecandidatename').val();
        var cidd = $('#candidateid').val();
        var cposition = $('#ecandidateposition').find(":selected").val();


        if (file) {
            formdata.append('image', file);
            formdata.append('isImage', true);
        }
        else {
            formdata.append('isImage', false);
        }

        formdata.append('candid', cidd);
        formdata.append('name', cname);
        formdata.append('position', cposition)

        $.ajax({
            url: "sql/update.candidate.php",
            type: "POST",
            data: formdata,
            processData: false,
            contentType: false,
        })
            .done(function (data) {

                let result = JSON.parse(data);

                if (result.res == "success") {


                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Candidate Updated',
                        timer: 2000,
                        showConfirmButton: false,
                        allowOutsideClick: false
                    }).then((result) => {

                    if (result.dismiss === Swal.DismissReason.timer) {
                        location.reload();
                    }
})

                }
                else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong',

                    })
                }
            });

    });

    $("#edelete").click(function () {
        var id = $('#candidateid').val();

        $.ajax({
            url: "sql/delete.candidate.php",
            type: "POST",
            data: {
                "canid": id,
            },
            success: function (data) {
                let result = JSON.parse(data);


                if (result.res == "success") {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Candidate Deleted',
                        timer: 2000,
                        showConfirmButton: false,
                        allowOutsideClick: false
                    }).then((result) => {
                    if (result.dismiss === Swal.DismissReason.timer) {

                        location.reload();

                    }
                })

                }
                else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Something went wrong',

                    })
                }
            }
        })


    });


    $('#example').on('click', 'td .edit', function (e) {
        var id = $(this).data("cid");

        $.ajax({
            url: "sql/fetch.candidate.php",
            type: "POST",
            data: {
                "canid": id,
            },
            success: function (data) {
                let json = JSON.parse(data);

                document.getElementById("ecandidatename").value = json[0].Name;
                document.getElementById("candidateid").value = json[0].id;
                document.getElementById("ecandidateposition").value = json[0].category_id;
            }
        })
    });

</script>
<?php
include "footervoting.html"

    ?>