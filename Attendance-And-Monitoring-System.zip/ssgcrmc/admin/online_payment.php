<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> CRMC SSG </title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg" />
    <link rel="stylesheet" href="adminstyles.css">

    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
    <div class="logo"><img src="images/logo.jpg"></div> 
      <span class="logo_name"> CRMC SSG</span>
    </div>
      <ul class="nav-links" style="margin-left: 12px;">
        <li>
          <a href="index.php">
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a><hr class="style">
        </li><hr class="style">
        <li>
          <a href="user_profile.php">
          <i class="uil uil-user"></i>
            <span class="links_name">User Profile</span>
          </a>
        </li>
        <li>
          <a href="student_info.php">
          <i class="uil uil-create-dashboard"></i>
            <span class="links_name">Student Information</span>
          </a>
        </li>
        <li>
          <a href="student_penalty.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Student Penalty</span>
          </a>
        </li>
        <li>
          <a href="online_payment.php" class="active">
          <i class="uil uil-bill"></i>
            <span class="links_name">Online Payment</span>
          </a>
        </li>
        <li>
          <a href="school_events.php">
          <i class="uil uil-notebooks"></i>
            <span class="links_name">School Events</span>
          </a>
        </li>
        <li>
          <a href="#">
          <i class="uil uil-users-alt"></i>
            <span class="links_name">Online Voting</span>
          </a>
        </li>
      </ul>
  </div>

  <section class="home-section">
    <nav>
      <div class="sidebar-button" style="color: white">
        <i class='il uil-arrow-circle-left sidebarBtn'></i>
      </div>

      <div class="profile-details">
        <i class="uil uil-user-circle"></i>
        <i class="bx bx-chevron-down" onclick="toggleMenu()"></i>

      <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
          <div class="user-info">
          <i class="uil uil-user-circle user"></i> 
          <h4>Admin Account</h4>
          <hr>
          </div>
         

          <a href="#" class="sub-menu-link">
          <i class="il uil-user-square usermenu"></i>
          <p>Profile</p>
          </a>
          <a href="logout.php" class="sub-menu-link">
          <i class="uil uil-signout usermenu"></i>
          <p>Log Out</p>
          </a>

        </div>
      </div>

      </div> 
    </nav>

    <div class="home-content">
 
    <div class="overview-boxes">
  
   <div class="con">          
      <i class="uil uil-bill"></i>
           <h3>Online Payment Information</h3>

           <label for="asd">Events</label>
           <select name="asd" id="asd" class="form-select w-25">
            <option value="">A</option>
            <option value="">B</option>
            <option value="">C</option>
            <option value="">D</option>
          </select>
           </div>

            <div class="containers py-5" style="width:1300px; height:600px; font-size: 13px; overflow-y: scroll; overflow-x:scroll; max-height:100vh">
            <div class="row">

          <table id="example" class="table table-striped" style="width:100%">
         
          

          <thead style="color: black">
          
            <tr>
                <th style="text-align: center"><b>ID</b></th>
                <th style="text-align: center"><b>STUDENT NAME</b></th>
                <th style="text-align: center"><b>STUDENT ID</b></th>
                <th style="text-align: center"><b>PROOF OF PAYMENT</b></th>
                <th style="text-align: center"><b>ACTION</b></th>
            </tr>
        </thead>
        <tbody>
          <style>
            td{
              text-align: left;
            }
          </style>
          <tr>
            <td>1</td>
            <td>JUAN</td>
            <td>101201213</td>
            <td>BSS-1</td>
            <td>
                <a href="#" class='btn btn-success btn-sm b' data-toggle='modal'><i class='uil uil-check' style='color:white; font-size:15px; text-align: center'></i> Accept</a> |
                <a href="#" class='btn btn-danger btn-sm b' data-toggle='modal'><i class='uil uil-ban' style='color:white; font-size:15px; text-align: center'></i> Denied</a>
            </td>
          </tr>

          <tr>
            <td>2</td>
            <td>PEDRO</td>
            <td>101201213</td>
            <td>BSS-2</td>
            <td>
            <a href="#" class='btn btn-success btn-sm b' data-toggle='modal'><i class='uil uil-check' style='color:white; font-size:15px; text-align: center'></i>Accept</a> |
            <a href="#" class='btn btn-danger btn-sm b' data-toggle='modal'><i class='uil uil-ban' style='color:white; font-size:15px; text-align: center'></i>Denied</a>
            </td>
          </tr>
        
          </thead>
      </table>
    </div>
</div>
    </div>  
  </section>

<script src="jquery/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="datatable/jquery.dataTables.min.js"></script>
<script src="datatable/dataTable.bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
<script src="script.js"></script>
  <script>
   let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
    sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("uil uil-angle-right");
}else
  sidebarBtn.classList.replace("uil uil-angle-right");
}
 </script>

<script>
  let subMenu = document.getElementById("subMenu");
  function toggleMenu(){
    subMenu.classList.toggle("open-menu");
  }
</script>

</body>
</html>
