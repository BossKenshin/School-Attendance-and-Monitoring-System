<?php
include "header.html"

  ?>

<?php

include './fragments/sidebar.php';
?>

<section class="home-section">
  <nav>
    <div class="sidebar-button">
      <i class="il uil-arrow-circle-left sidebarBtn"></i>
    </div>

    <div class="profile-details">
      <i class="uil uil-user-circle"></i>
      <i class="bx bx-chevron-down" onclick="toggleMenu()"></i>

      <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
          <div class="user-info">
            <i class="uil uil-user-circle user"></i>
            <h4>Admin Account</h4>
            <hr>
          </div>


          <a href="user_profile.php" class="sub-menu-link">
            <i class="il uil-user-square usermenu"></i>
            <p>Profile</p>
          </a>
          <a href="admin_logout.php" class="sub-menu-link">
            <i class="uil uil-signout usermenu"></i>
            <p>Log Out</p>
          </a>

        </div>
      </div>
    </div>
  </nav>

  <div class="home-content">
    <div class="overview-boxes">

      <div class="con">
        <i class="uil uil-notebooks"></i>
        <h3>School Events</h3>
        <div class="sat" style="display: flex;justify-content:right;width:1000px; font-size: 13px; max-height:100vh">
          <button type="button" class="btn btn-success uil uil-plus" style="  background-color: #66db93;color:black"><a
              href="school_events_addevents.php" style="Color:black; text-decoration: none">Create Event</a></button>
        </div>
      </div>

      <div class="containers py-5" style="width:1300px" data-aos="fade-up">

        <div class="row">
          <section id="chefs" class="chefs section-bg">

            <div class="row gy-4">
              <?php
              include 'sql/dbconnect.php';
              $location = 'images/';
              $sql = "SELECT * FROM event WHERE status ='Active'ORDER BY Id DESC";
              $stmt = mysqli_query($conn, $sql);
              while ($row = mysqli_fetch_object($stmt)) {
                ?>
                <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
                  <div class="chef-member">
                    <div class="member-img">
                      <img src=<?php
                      $image;
                      if($row->img == 0){
                          $image = "chefs-1.jpg";
                      }else{
                          $image =  $row->img;
                      }
                       echo '"' . $location .$image. '"'; 
                       
                       ?> class="img-fluid" alt="">
                      <div class="social">
                        <a href="school_events_update.php?id=<?php echo $row->Id ?>"><i class="uil uil-edit "></i></a>

                      </div>
                    </div>
                    <div class="member-info" >
                      <h4 style="position: relative; top: -20px;">
                        <?= $row->What ?>
                      </h4>
                      <h5 class="mt-5">
                        <?php echo 'When: ' . $row->When ?>
                      </h5>
                      <h5>
                        <?php echo 'Where: ' . $row->Where ?>
                      </h5>
                    </div>
                  </div>
                </div>
              <?php } ?>
            </div>

          </section>
        </div>
      </div>
    </div>
  </div>
</section>


<?php
include "footer.html"

  ?>