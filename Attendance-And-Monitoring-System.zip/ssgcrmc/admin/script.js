let notifMenu = document.getElementById("notifMenu");
  function toggleMenu(){
    notifMenu.classList.toggle("open-menu");
  }

  $(document).ready(function () {

    $.ajax({
      url: "sql/event.first.php",
      success: function (data) {
      var deptData = JSON.parse(data);

      // if(){
        
      // }

      $("#example").DataTable({
        data: deptData,
        columns: [
        { data: "student_id_no" },
        { data: "Name" },
        { data: "What" },
        { data: "When" },
        ],
    });

  },

});
$("#example1").DataTable();
$("#examples").DataTable();
$("#examples1").DataTable();



  
} );