<?php

require "sql/dbconnect.php";
session_start();

$adminid = $_SESSION['admin_uid'];

if (!isset($_SESSION['admin_uid'])) {
  header("location: ../index.php");
}


$admin = "SELECT * FROM students;";
$qr = mysqli_query($conn, $admin);

$numstudents = mysqli_num_rows($qr);


$notpaid = "SELECT * FROM event_penalty WHERE Status = 'unpaid';";
$qr1 = mysqli_query($conn, $notpaid);

$numnotpaid= mysqli_num_rows($qr1);

$paid = "SELECT * FROM event_penalty WHERE Status = 'paid';";
$qr2 = mysqli_query($conn, $paid);

$numpaid= mysqli_num_rows($qr2);


$events = "SELECT * FROM event WHERE status = 'active';";
$qr3 = mysqli_query($conn, $events);

$numevents= mysqli_num_rows($qr3);






?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

  <head>
    <meta charset="UTF-8">
    <title> CRMC SSG </title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg" />
    <link rel="stylesheet" href="adminstyles.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.2/xlsx.full.min.js"
        integrity="sha512-qilAGdDSZ5c0sTjizcSCffmIb8D2rHttMYGUxtI3OFn8lB29BlU2tEUcPesHHLQ2t0Y5TInglWKY6V3GoSK0IA=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>

<body>
    
<?php

include './fragments/sidebar.php';
?>
 

  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='il uil-arrow-circle-left sidebarBtn'></i>
        
      </div>

      <!-- <div class="search-box">
        <input type="text" placeholder="Search...">
        <i class='bx bx-search'></i>
      </div> -->

      <div class="profile-details">
       
        <i class="uil uil-user-circle"></i>
        <i class="bx bx-chevron-down" onclick="toggleMenu()"></i>

      <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
          <div class="user-info">
          <i class="uil uil-user-circle user"></i> 
          <h6>Admin Account</h6>
          <hr>
          </div>
       

          <a href="user_profile.php" class="sub-menu-link">
          <i class="il uil-user-square usermenu"></i>
          <p>Profile</p>
          </a>
          <a href="admin_logout.php" class="sub-menu-link">
          <i class="uil uil-signout usermenu"></i>
          <p>Log Out</p>
          </a>

        </div>
      </div>

      </div> 
    </nav>

    <div class="home-content">
    <div class="dashboard">
      <br>
      <h4><b><u>Dashboard</u></b>/ Admin Panel</h4>
      </div>
      <br><br>

      <div class="overview-boxes">
        <div class="box">
        <i class="uil uil-create-dashboard cart"></i>
          <div class="right-side">          
            <div class="box-topic">No. Students</div>
                  <div class="number"><?php echo $numstudents ?></div>
            <!-- <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
              <span class="text"><a href="#">Full Details</a></span>
            </div> -->
          </div>
         
        </div>
        <div class="box">
        <i class="uil uil-file-check cart two"></i>
          <div class="right-side">
            <div class="box-topic">Paid Penalty</div>
              <div class="number"><?php echo $numpaid ?></div>
                 
            <!-- <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
              <span class="text"><a href="#">Full Details</a></span>
            </div> -->
          </div>
         
        </div>
        <div class="box">
        <i class="uil uil-exclamation-circle cart three"></i>
          <div class="right-side">
            <div class="box-topic">Unpaid Penalty</div>
                <div class="number"><?php echo $numnotpaid ?></div>
            <!-- <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
              <span class="text"><a href="#">Full Details</a></span>
            </div> -->
          </div>
          
        </div>

        <div class="box">
        <i class="uil uil-parcel cart four"></i>
          <div class="right-side">
            <div class="box-topic">School Events</div>
               <div class="number"><?php echo $numevents ?></div>
            <!-- <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
              <span class="text"><a href="#">Full Details</a></span>
            </div> -->
          </div>
          
        </div>
          
      
        <div class="con">          
                <i class="uil uil-sign-alt"></i>
                <h3>Students</h3>
                </div>
   
    <div class="containers py-5" style="width:1300px; height:400px; font-size: 13px; overflow-y: scroll; overflow-x:scroll; max-height:100vh">
    <div class="row">

    <table id="example1" class="table table-striped" style="width:100%">
        <thead style="color: black; background: #6237A0; font-weight:1000px;">
            <tr>
                <th style="text-align: center"><b>ID</b></th>
                <th style="text-align: center"><b>STUDENT NAME</b></th>
                <th style="text-align: center"><b>STUDENT ID</b></th>
                <th style="text-align: center"><b>COURSE & YEAR</b></th>
                <th style="text-align: center"><b>EMAIL</b></th>
                <th style="text-align: center"><b>GENDER</b></th>
                <th style="text-align: center"><b>USERNAME</b></th>
                <th style="text-align: center"><b>PASSWORD</b></th>

            </tr>
        </thead>
        <tbody>
          <style>
            td{
              text-align: left;
            }
          </style>
         <tr>
                          <?php 
                          include './sql/dbconnect.php';

                            $sql = "SELECT * FROM students";
                            $stmt = mysqli_query($conn,$sql);
                           
                            while($row = mysqli_fetch_object($stmt)){
                             ?>  
                                  
                                  <td><?= $row->stid ?></td>
                                  <td><?= $row->firstname.' '.$row->lastname?></td>
                                  <td><?= $row->student_id_no ?></td>
                                  <td><?= $row->course_year?></td>
                                  <td><?= $row->email?></td>
                                  <td><?= $row->gender?></td>
                                  <td><?= $row->st_username?></td>
                                  <td><?= $row->st_password?></td>


                              </tr>
                              <?php } ?>
           
        </tbody>
      
      </table>        
    </div>
</div> 
  </section>


<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
<script src="script.js"></script>

  <script>
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
      sidebarBtn.onclick = function() {
      sidebar.classList.toggle("active");
        if(sidebar.classList.contains("active")){
            sidebarBtn.classList.replace("uil uil-angle-right");
        }else
            sidebarBtn.classList.replace("uil uil-angle-right");
      }
 </script>

<script>
  let subMenu = document.getElementById("subMenu");
  function toggleMenu(){
    subMenu.classList.toggle("open-menu");
  }


  let selectedFile;
        var DBstudentObject;
        var rowStudentList;

        document
            .getElementById("excelfile")
            .addEventListener("change", (event) => {
                selectedFile = event.target.files[0];
            });

        document
            .getElementById("addMultipleStudent")
            .addEventListener("click", () => {
                //  let rowObject;
                if (selectedFile) {
                    let fileReader = new FileReader();
                    fileReader.readAsBinaryString(selectedFile);
                    fileReader.onload = (event) => {
                        let data = event.target.result;
                        let workbook = XLSX.read(data, { type: "binary" });
                        workbook.SheetNames.forEach((sheet) => {
                            rowStudentList = XLSX.utils.sheet_to_row_object_array(
                                workbook.Sheets[sheet]
                            );
                        });

                        var regExp = /[a-zA-Z]/;
                        var len = rowStudentList.length;
                        var _hasrun = false;
                       
                        for (var i = 0; i < rowStudentList.length; i++) {
                        var randomUsername = generateRandomUsername(); // Generate a random username with 8 characters
                        var randomPassword = generateRandomPassword();
                            if (rowStudentList[i].hasOwnProperty("ID Number") && rowStudentList[i].hasOwnProperty("First Name") && rowStudentList[i].hasOwnProperty("Last Name") && rowStudentList[i].hasOwnProperty("Email") && rowStudentList[i].hasOwnProperty("Gender")) {
                                if (!regExp.test(rowStudentList[i]['ID Number'])) {
                                    $.ajax({
                                        url: "./add.student.php",
                                        type: "GET",
                                        data: {
                                            sid: rowStudentList[i]['ID Number'],
                                            sfn: rowStudentList[i]['First Name'],
                                            sln: rowStudentList[i]['Last Name'],
                                            email: rowStudentList[i]['Email'],
                                            gen: rowStudentList[i]['Gender'],
                                            cny: rowStudentList[i]['Course & Year'],
                                            user: randomUsername,
                                            pass: randomPassword,
                                        },
                                    }).done(function () {
                                        if ((i = len)) {
                                            if (_hasrun === false) {
                                                // $("#studentTable").DataTable().clear().destroy();
                                                // setStudentTable();
                                                /*RERUN THE FETCHING OF DATA AFTER NEW DATA ADDED */
                                                _hasrun = true;
                                                alert("Student saved to database successfully!!")
                                            }
                                        }
                                    });
                                }
                            } else {
                                /*ALERT FUNCTION IF THE FILE IS WRONG */
                                alert("Wrong File");
                                // Swal.fire({
                                // icon: "Error",
                                // title: "Oops...",
                                // text: "You have selected a wrong file",
                                // });
                            }
                        }
                        document.querySelector("#excelfile").value = "";
                    };
                } else {
                    /*ALERT FUNCTION IF MISSING A FILE ON SUBMIT */
                    alert("No File");
                    // Swal.fire({
                    //     icon: "error",
                    //     title: "Oops...",
                    //     text: "Please fill in the missing details!!",
                    // });
                }
            });




        function generateRandomUsername() {
            const characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            let username = '';

            for (let i = 0; i < 8; i++) {
                const randomIndex = Math.floor(Math.random() * characters.length);
                username += characters.charAt(randomIndex);
            }

            return username;
        }

        function generateRandomPassword() {
            const characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#&()';
            let password = '';

            for (let i = 0; i < 8; i++) {
                const randomIndex = Math.floor(Math.random() * characters.length);
                password += characters.charAt(randomIndex);
            }

            return password;
        }

        // Usage example:
         // Generate a random password with 10 characters

        // console.log('Random Username:', randomUsername);
        // console.log('Random Password:', randomPassword);

</script>

</body>
</html>
