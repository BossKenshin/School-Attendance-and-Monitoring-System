<div class="sidebar">
    <div class="logo-details">
        <div class="logo"><img src="images/logo.jpg"></div>
        <span class="logo_name">CRMC SSG</span>
    </div>
    <ul class="nav-links">
        <li>
            <a href="index.php" class="active">
                <i class='bx bx-grid-alt'></i>
                <span class="links_name">Dashboard</span>
            </a>
            <hr>
        </li>
        <hr>
        <li>
            <a href="user_profile.php">
                <i class="uil uil-user"></i>
                <span class="links_name">User Profile</span>
            </a>
        </li>
        <li>
            <a href="student_info.php">
                <i class="uil uil-create-dashboard"></i>
                <span class="links_name">Student Information</span>
            </a>
        </li>
        <li>
          <a href="student_penalty.php" >
            <i class="uil uil-book-reader"></i>
            <span class="links_name">Student Penalty</span>
          </a>
        </li>
        <li>
            <a href="student_payment.php">
                <i class="uil uil-user"></i>
                <span class="links_name">Payments</span>
            </a>
        </li>
        <li>
            <a href="student_olpayment.php">
                <i class="uil uil-credit-card-search"></i>
                <span class="links_name">Student OL Payment</span>
            </a>
        </li>

        <li>
          <a href="school_events.php">
          <i class="uil uil-parcel"></i>
            <span class="links_name">School Events</span>
          </a>
        </li>
        <li>
            <a href="controller.php?page=home">
                <i class="uil uil-users-alt"></i>
                <span class="links_name">Online Voting</span>
            </a>
        </li>
       
        <li>
            <a href="manage.voting.php">
                <i class="uil uil-file-search-alt"></i>
                <span class="links_name"> Manage Voting</span>
            </a>
        </li>
      
      
    </ul>
</div>