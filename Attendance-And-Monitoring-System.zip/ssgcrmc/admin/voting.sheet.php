<?php
require "sql/dbconnect.php";
session_start();

if (!isset($_SESSION['student_uid'])) {
    header("location: ../user/user.login.php");
}

?>


<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <title> CRMC SSG </title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg" />
    <link rel="stylesheet" href="adminstyles.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.2/xlsx.full.min.js"
        integrity="sha512-qilAGdDSZ5c0sTjizcSCffmIb8D2rHttMYGUxtI3OFn8lB29BlU2tEUcPesHHLQ2t0Y5TInglWKY6V3GoSK0IA=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

    <div class="container-fluid mb-4">

            <p class="h1 text-center">CRMC SSG <br> VOTING SHEET</p>

        <form method="post" class="form-control" id="manage-vote">
            <?php
            require "sql/dbconnect.php";
            $position = "SELECT * FROM category_list";
            $positions = mysqli_query($conn, $position);

            while ($rows = mysqli_fetch_assoc($positions)) {
                ?>
                <div class="container">

                    <br>
                    <hr>
                    <p class="h1 text-center">
                        <?php echo $rows['category'] ?>
                    </p>
                    <div class="row container d-flex align-items-center justify-content-between" ">
                            <?php
                            $opt = "SELECT * FROM voting_opt";
                            $opts = mysqli_query($conn, $opt);
                            while ($row = mysqli_fetch_assoc($opts)) {
                                if ($row['category_id'] == $rows['id']) {
                                    ?>
                                    <div class=" col-md-4 text-center">
                        <div class="container" style="width: 200px;">
                            <img src="assets/img/<?php echo $row['image_path'] ?>" alt="" class="img-fluid">
                        </div>
                        <div class="container d-flex w-50">
                            <input class="form-check-input h4 posi" type="checkbox"
                                name="<?php echo str_replace(' ', '', $rows['category']); ?>" onclick="chkClicked(this)"
                                value="<?php echo $row['id'] ?>">

                            <p class="h4 mx-3">
                                <?php echo $row['Name']; ?>
                            </p>


                        </div>

                    </div>

                    <?php
                                }
                            }
                            ?>
                </div>

        </div>


        <?php
            }
            ?>
    <div class="container p-4 bg-light shadow" style="display:flex; align-items: center; justify-content: center;">
    <p class="h5 me-2">Are you done voting? Click here : </p>
        <input class="btn btn-success me-4" type="submit" value="Submit">
            <a class="btn btn-danger" href="ssg.landingpage.php">  Exit  </a>
    </div>
    </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
    <script>
        var parray = new Array();


        function chkClicked(element) {
            // console.log(element.getAttribute("name"));
            // parray = Array.push(element.getAttribute("name"));
            //     console.log(parray);
        }


        $('#manage-vote').submit(function (e) {
            e.preventDefault()
           var data = $(this).serialize();
                var myarray = data.split('&');
                var positionarray = new Array();
                for (var i = 0; i < myarray.length; i++){

                    var newarray = myarray[i].split("=");
                    positionarray.push(newarray[0]);
                }
            let dupValue = positionarray.filter((c, index) => {
                    return positionarray.indexOf(c) !== index;
                });
                // console.log(dupValue);

                if(dupValue.length == 0){
            $.ajax({
                url: 'sql/add.vote.php',
                method: 'POST',
                data: $(this).serialize(),
                success: function (data) {
                    if (data == 0) {
                        Swal.fire({ title: 'Vote submitted', confirmButtonText: 'Yes, confirm', })
                            .then((result) => {
                                if (result.isConfirmed) {

                                    location.href = "ssg.landingpage.php";

                                }
                            });

                    }
                    else if(data == 3){
                        Swal.fire({ title: 'Vote one candidate on all positions', confirmButtonText: 'Yes, confirm', })

                    }
                    else {

                        Swal.fire({ title: 'Multiple votes in one position',text: 'Select only one candidate per position', confirmButtonText: 'Okay, got it!', })

                    }
                }
            })

        }
        else{
            Swal.fire({ title: 'Multiple votes in one position',text: 'Select only one candidate per position', confirmButtonText: 'Okay, got it!', })
        }
        })
    </script>
</body>

</html>