<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> CRMC SSG </title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg" />
    <link rel="stylesheet" href="adminstyles.css">

    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
   </head>
<body>
   
<?php

include './fragments/sidebar.php';
?>
 <!-- -----------------------------MODAL---------------------------- -->
 <div class="modal " id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Upload Transaction Payment</h5>
              </div>
              <div class="modal-body">
              <form>
                  <div class="form-group">
                    <label for="recipient-name" class="col-form-label">Penalty:</label>
                    <input type="number" class="form-control" id="penalty">
                  </div>
                </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary"  id="close" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="submit">Confirm Payment</button>
              </div>
            </div>
          </div>
        </div>

          <!-- --------------------------------------------------------- -->

  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='il uil-arrow-circle-left sidebarBtn'></i>
      </div>

      <div class="profile-details">
        <i class="uil uil-user-circle"></i>
        <i class="bx bx-chevron-down" onclick="toggleMenu()"></i>

      <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
          <div class="user-info">
          <i class="uil uil-user-circle user"></i> 
          <h4>Admin Account</h4>
          <hr>
          </div>
         

          <a href="user.profile.php" class="sub-menu-link">
          <i class="il uil-user-square usermenu"></i>
          <p>Profile</p>
          </a>
          <a href="admin_logout.php" class="sub-menu-link">
          <i class="uil uil-signout usermenu"></i>
          <p>Log Out</p>
          </a>

        </div>
      </div>

      </div> 
    </nav>

  

    <div class="home-content">
 
 <div class="overview-boxes">
  
   <div class="con">          
           <i class="uil uil-sign-alt"></i>
           <h3>Student Online Payment Information</h3>
           </div>

            <div class="containers py-5" style="width:1300px; height:600px; font-size: 13px; overflow-y: scroll; overflow-x:scroll; max-height:100vh">
            <div class="row">

          <table id="examples" class="table table-striped" style="width:100%">
         
          

          <thead style="color: black">
          
            <tr>
                <th style="text-align: center;"><b>PENALTY ID</b></th>
                <th style="text-align: center"><b>STUDENT NAME</b></th>
                <th style="text-align: center"><b>STUDENT ID</b></th>
                <th style="text-align: center"><b>EVENT NAME</b></th>
                <th style="text-align: center"><b>WHEN</b></th>
                <th style="text-align: center"><b>PENALTY AMOUNT</b></th>
                <th style="text-align: center"><b>ACTION</b></th>
            </tr>
        </thead>
        <tbody>
          <style>
            td{
              text-align: left;
            }
          </style>
          <tr>
          <?php 
                          include './sql/dbconnect.php';

                          $sql = "SELECT students.stid,students.student_id_no,CONCAT(students.firstname,' ',students.lastname) As Name ,event.Id AS eventID,event.What,event.When,event_penalty.* From event INNER join event_penalty ON event_penalty.event_Id = event.Id INNER JOIN students ON event_penalty.student_Id = students.stid WHERE  event_penalty.Status = 'Unpaid'";
                          $stmt = mysqli_query($conn,$sql);
                            while($row = mysqli_fetch_object($stmt)){
                              ?>  

                                  
                                  <td><?= $row->Id ?></td>
                                  <td><?= $row->Name?></td>
                                  <td><?= $row->student_id_no ?></td>
                                  <td><?= $row->What?></td>
                                  <td><?= $row->When?></td>
                                  <td><?= $row->penalty?></td>
                                 
                                  <td>
                                      <!-- <button class="btn btn-success" id="viewbtn">View</button> -->
                                      <button class="btn btn-success uplod-btn" data-sid="<?= $row->stid?>" data-id="<?= $row->eventID?>" data-amount="<?= $row->penalty?>"  id="upload_btn">Pay</button>

                                  </td>
                              </tr>
                              <?php } ?>
        </tbody>
      </table>
    </div>
</div>
    </div>  
  </section>

<script src="jquery/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="datatable/jquery.dataTables.min.js"></script>
<script src="datatable/dataTable.bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
<!-- <script src="script.js"></script> -->
  <script>
     var id;
    var amount;
    var stId;


       $('#close').click(function() {
       
       $('#exampleModal').toggle();
       document.querySelector("form").reset();
     
   });
$('.uplod-btn').click(function() {
         id = $(this).data('id'); 
          amount = $(this).data('amount'); 
           stId = $(this).data('sid'); 
           $('#penalty').val(amount);
        $('#exampleModal').show();
      
    });

    $('#submit').click(function() {
     var event_Id = id;
     var penal_amount = amount;
     var student_ID = stId;
     Swal.fire({ title: 'Confirm Payment?',text: 'cant revert back once confirmed', showDenyButton: true, confirmButtonText: 'Yes', denyButtonText: `No`, })
       .then((result) => {
         if (result.isConfirmed) {
           // send data to server
           $.ajax({
             url: "sql/pay.counter.php",
             type: "GET",
             data: {
               ID: event_Id,
              St_ID: student_ID
             }
           })
             .done(function (data) {
               let result = JSON.parse(data);
               if (result.res == "success") {


                
                Swal.fire({ title: 'Successfully  Paid',  confirmButtonText: 'Yes',  })
      .then((result) => {
        if (result.isConfirmed) {
          document.querySelector("form").reset();
                 $('#exampleModal').toggle();
                 location.reload();


        }
        });

                
                 // const divElement = document.getElementById("pic");
                 // divElement.style.backgroundImage = "url(images/photo.png)";
            
                     }
                     
                     else{
                         alert2("Error, Something happened");
                     }
                 });
              
 
               }
               else if (result.isDenied) {
 
                 document.querySelector("form").reset();
                 $('#exampleModal').toggle()
                 Swal.fire('Payments are not saved', '', 'info')
               }
               else {
                 Swal.fire({
                   icon: 'error',
                   title: 'Empty',
                   text: 'Fill out the form to Add event',
                   showConfirmButton: true,
                   allowOutsideClick: true
                 })
               }
             });
      
    });



   let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
    sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("uil uil-angle-right");
}else
  sidebarBtn.classList.replace("uil uil-angle-right");
}
 </script>

<script>
  let subMenu = document.getElementById("subMenu");
  function toggleMenu(){
    subMenu.classList.toggle("open-menu");
  }
</script>

</body>
</html>
