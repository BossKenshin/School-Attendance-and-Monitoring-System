<!DOCTYPE html>
<html lang="en" dir="ltr">

  <head>
    <meta charset="UTF-8">
    <title> Voting Categories </title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg" />
    <link rel="stylesheet" href="adminstyles.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.2/xlsx.full.min.js"
        integrity="sha512-qilAGdDSZ5c0sTjizcSCffmIb8D2rHttMYGUxtI3OFn8lB29BlU2tEUcPesHHLQ2t0Y5TInglWKY6V3GoSK0IA=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>

<body>
    
<?php

include './fragments/sidebar.php';
include('./sql/dbconnect.php') ;

	
?>
 
 

  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='il uil-arrow-circle-left sidebarBtn'></i>
        
      </div>

      <div class="search-box">
        <input type="text" placeholder="Search...">
        <i class='bx bx-search'></i>
      </div>

      <div class="profile-details">
       
        <i class="uil uil-user-circle"></i>
        <i class="bx bx-chevron-down" onclick="toggleMenu()"></i>

      <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
          <div class="user-info">
          <i class="uil uil-user-circle user"></i> 
          <h6>Admin Account</h6>
          <hr>
          </div>
       

          <a href="#" class="sub-menu-link">
          <i class="il uil-user-square usermenu"></i>
          <p>Profile</p>
          </a>
          <a href="#" class="sub-menu-link">
          <i class="uil uil-signout usermenu"></i>
          <p>Log Out</p>
          </a>

        </div>
      </div>

      </div> 
    </nav>

    <div class="home-content">
    <div class="dashboard">
      <br>
      <h4><b><u> Voting Categories</u></b>/ Admin Panel</h4>
      </div>
      <br><br>

     <!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <div class="form-group">
                                    <label for="completecategory">Category</label>
                                    <input type="text" class="form-control" id="completecategory" >
                            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" onclick="addCategory()" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
          
      <div class="con">          
                <i class="uil uil-sign-alt"></i>
                <h3>Recent Events</h3>
                </div>
   
    <div class="containers py-5" style="width:1100px; height:400px; font-size: 13px; overflow-y: scroll; overflow-x:scroll; max-height:100vh">
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Add Category
</button>
    <div class="row">
   
    <table id="example" class="table table-striped" style="width:100%">
        <thead style="color: black; background: #6237A0; font-weight:1000px;">
            <tr>
                
                <th style="text-align: center"><b>Categoy Name</b></th>
                <th style="text-align: center"><b>Action</b></th>
            </tr>
        </thead>
        <tbody>
          <style>
            td{
              text-align: left;
            }
          </style>
         <tr>
                          <?php 
                          include './sql/dbconnect.php';

                            $sql = "SELECT * FROM category_list";
                            $stmt = mysqli_query($conn,$sql);
                           
                            while($row = mysqli_fetch_object($stmt)){
                             ?>  
                                  
                                  <td><?= $row->category ?></td>
                               
                                  <td>
                                      <button class="btn btn-danger" id="viewbtn">Delete</button>

                                  </td>
                              </tr>
                              <?php } ?>
           
        </tbody>
      
    </table>        
    </div>
	
     
    </div>
  

</div> 
  </section>

 
  <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
<script src="script.js"></script>

  <script>
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
      sidebarBtn.onclick = function() {
      sidebar.classList.toggle("active");
        if(sidebar.classList.contains("active")){
            sidebarBtn.classList.replace("uil uil-angle-right");
        }else
            sidebarBtn.classList.replace("uil uil-angle-right");
      }
 </script>

<script>
  function addCategory(){
            var catAdd=$('#completecategory').val()
           
           
           
            $.ajax({
                url:"category-add.php",
                type:'post',
                data:{
                    catSend:catAdd,
                   
                },
                success:function(data,status){
                    swal("New Category Added Successfully", "", "success").then(function(){
                        window.location.reload();
                        location.reload();
                    });
                }
            });

		
        }
	

</script>

</body>
</html>
