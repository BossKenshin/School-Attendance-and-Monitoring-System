
<?php
include './sql/dbconnect.php';
extract($_POST); 
  if(isset($_POST['catSend']) ) {
     $query="INSERT INTO category_list (category) VALUES 
     ('$catSend')";
       $result = mysqli_query($conn,$query);
  }
