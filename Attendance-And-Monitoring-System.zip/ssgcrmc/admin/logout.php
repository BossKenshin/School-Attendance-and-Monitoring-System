<?php

session_destroy();
session_unset();
header("location: ../user/user.login.php");



?>