<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> CRMC SSG </title>
  <link rel="icon" type="image/x-icon" href="images/logo.jpg" />
  <link href="style.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"
    integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
  <link href="bootstrap/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <link href="aos/aos.css" rel="stylesheet">



  <link
    href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
    rel="stylesheet">


</head>

<body>

  <header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a class="logo d-flex align-items-center">
        <img src="images/logo.jpg" alt="">
        <span>CRMC SSG</span>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#values">Events</a></li>
          <li><a class="nav-link scrollto" href="voting.sheet.php" 
            <?php
            session_start();
            include 'sql/dbconnect.php';
            $st = "SELECT * FROM votes WHERE stid = ".$_SESSION['student_uid'];
              $q = mysqli_query($conn,$st);

              if(mysqli_num_rows($q) != 0){
                  echo "hidden";
              }
        

            ?>
            >Voting</a></li>
           
          <li><a class="getstarted scrollto" href="logout.php">
              Logout
            </a></li>
            <li class="fs-3 mx-2" >
              <?php 
              echo $_SESSION['student_name']; ?>
            </li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle">
        </i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="hero d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center">
          <h1 data-aos="fade-up">We offer helpful initiatives to enhance the student experience</h1>
          <h2 data-aos="fade-up" data-aos-delay="400">Creating an environment that embraces diversity and promotes equal
            opportunities.</h2>
          <div data-aos="fade-up" data-aos-delay="600">
            <div class="text-center text-lg-start">

            </div>
          </div>
        </div>
        <div class="col-lg-6 hero-img" data-aos="zoom-out" data-aos-delay="200">
          <img src="images/logo.jpg" class="img-fluid" alt="">
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Event Section ======= -->
    <section id="values" class="values">

      <div class="container" data-aos="fade-up">

        <header class="section-header">
          <p>CRMC EVENTS</p>
        </header>

        <div class="row">
          <?php
          include 'sql/dbconnect.php';
          $location = 'images/';
          $sql = "SELECT * FROM event WHERE status ='Active'ORDER BY Id DESC";
          $stmt = mysqli_query($conn, $sql);
          while ($row = mysqli_fetch_object($stmt)) {
            ?>
            <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
              <div class="box">
                <img src=<?php echo '"' . $location . $row->img . '"'; ?> class="img-fluid" alt="">
                <h3>
                  <?php echo $row->What ?>
                </h3>
                <h4>
                  <?php echo 'When: ' . $row->When ?>
                </h4>
                <h4>
                <?php echo 'Time: '. date('h:i a', strtotime($row->timein)).' - '.date('h:i a', strtotime($row->timeout)) ?>

                </h4>
                <h4>
                  <?php echo 'Where: ' . $row->Where ?>
                </h4>

                <?php
                $dateevent = $row->When;
                $datenow = date("Y-m-d");


                if ($dateevent >= $datenow) {
                  ?>
                  <button class="btn btn-success attendbtn" id="attendancebtn" data-when="<?php echo $row->When ?>" data-timein="<?php echo $row->timein ?>" data-timeout="<?php echo $row->timeout ?>" data-lati="<?php echo $row->lati;?>"
                    data-longi="<?php echo $row->longi; ?>" data-stid="<?php echo $_SESSION['student_uid']; ?>"
                    data-eventid=<?php echo $row->Id; ?>>Attendance</button>
                  <?php
                } else {
                  echo "<button class='btn btn-danger' disabled >Attendance Closed</button>";
                }

                ?>
              </div>
            </div>

          <?php } ?>

        </div>

      </div>

    </section><!-- End Events Section -->
    <!-- -----------------------------MODAL---------------------------- -->
    <div class="modal " id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Upload Transaction Payment</h5>
              </div>
              <div class="modal-body">
              <div class="col-lg-4 col-md-6 reservation-img" id="pic" style="background-image: url(images/photo.png)"
              data-aos="zoom-out" data-aos-delay="200"></div>

                <form>
             
                <div class="form-group">
                  <input type="file" name="file" onchange="changeBackgroundImage(event)" id="pics" 
                    accept="image/*" required />
                    </div>
               
                </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary"  id="close" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="submit">Save Changes</button>
              </div>
            </div>
          </div>
        </div>

          <!-- --------------------------------------------------------- -->

       <!-- ======= Penalty Section ======= -->
       <section id="penalty" class="values">

                            <div class="container" data-aos="fade-up">

                              <header class="section-header">
                                <p>Penalty </p>
                              </header>
                              <div class="con">          
                                <h3>Recent Penalty Events</h3>
                           </div>
  
    <div class="row">

    <table id="example1" class="table table-striped" style="width:100%">
        <thead style="color: black;">
            <tr>
                <th style="text-align: center"><b>PENALTY ID</b></th>
                <th style="text-align: center"><b>STUDENT NAME</b></th>
                <th style="text-align: center"><b>STUDENT ID</b></th>
                <th style="text-align: center"><b>EVENT NAME</b></th>
                <th style="text-align: center"><b>WHEN</b></th>
                <th style="text-align: center"><b>PENALTY AMOUNT</b></th>
                <th style="text-align: center"><b>ACTION</b></th>
            </tr>
        </thead>
        <tbody>
          <style>
            td{
              text-align:center;
            }
          </style>
    
                          <?php 
                       
                          include './sql/dbconnect.php';

                            $sql = "SELECT students.stid,students.student_id_no,CONCAT(students.firstname,' ',students.lastname) As Name ,event.Id AS eventID,event.What,event.When,event_penalty.* From event INNER join event_penalty ON event_penalty.event_Id = event.Id INNER JOIN students ON event_penalty.student_Id = students.stid WHERE students.stid ='".$_SESSION['student_uid']."' AND event_penalty.Status = 'Unpaid'";
                            $stmt = mysqli_query($conn,$sql);
                           
                            while($row = mysqli_fetch_object($stmt)){
                             ?>  
                                       <tr>
                                  <td><?= $row->Id ?></td>
                                  <td><?= $row->Name?></td>
                                  <td><?= $row->student_id_no ?></td>
                                  <td><?= $row->What?></td>
                                  <td><?= $row->When?></td>
                                  <td><?= $row->penalty?></td>
                                 
                                  <td>
                                      <!-- <button class="btn btn-success" id="viewbtn">View</button> -->
                                      <button class="btn btn-warning uplod-btn" data-vid="<?= $row->eventID?>" data-id="<?= $row->Id?>" data-amount="<?= $row->penalty?>"  id="upload_btn">Upload</button>

                                  </td>
                              </tr>
                              <?php } ?>
           
        </tbody>
      
      </table>        

</div> 
                             

                            </div>

                            </section><!-- End Values Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>SSG</span></strong>. All Rights Reserved
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="uil uil-arrow-up"></i></a>

  <!-- Vendor JS Files -->
  <script>
    $('#navbar').click(function () {
      // console.log("Hai");


    });
  </script>

  <script src="aos/aos.js"></script>

  <script src="jquery/jquery.min.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>
  <script src="datatable/jquery.dataTables.min.js"></script>
  <script src="datatable/dataTable.bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 
  <script src="main.js"></script>
  <!-- <script src="script.js"></script> -->

  <script>
    var id;
    var amount;
    var eveId;
     $('#close').click(function() {
       
        $('#exampleModal').toggle();
        document.querySelector("form").reset();
      
    });
 $('.uplod-btn').click(function() {
         id = $(this).data('id'); 
          amount = $(this).data('amount'); 
           eveId = $(this).data('vid'); 
         
        $('#exampleModal').show();
        console.log(amount,id,eveId);
      
    });
    $('#submit').click(function() {
       
      var up = $("#pics").val().length;
    if (up > '0') {
      var pic = $('#pics').val().replace(/.*(\/|\\)/, '');
    }
    else {
      var pic = '0';
    }
    var penal_Id = id;
    var penal_amount = amount;
    var Event_ID = eveId;
    Swal.fire({ title: 'Got the payment receipt attach?', showDenyButton: true, confirmButtonText: 'Yes', denyButtonText: `No`, })
      .then((result) => {
        if (result.isConfirmed) {
          // send data to server
          $.ajax({
            url: "sql/pay.penalty.php",
            type: "GET",
            data: {
              ID: penal_Id,
              Event: Event_ID,
              pAmount: penal_amount,
              Pic: pic
      
            }
          })
            .done(function (data) {
              let result = JSON.parse(data);
              if (result.res == "success") {

                
                uploadpic();

                Swal.fire({ title: 'Payment proof uploaded',  confirmButtonText: 'Yes',  })
      .then((result) => {
        if (result.isConfirmed) {
                $('#exampleModal').toggle();
            location.reload();

        }
        });

                // const divElement = document.getElementById("pic");
                // divElement.style.backgroundImage = "url(images/photo.png)";
           
                    }else{
                        alert2("Error, Something happened");
                    }
                });
               

              }
              else if (result.isDenied) {

                document.querySelector("form").reset();
                // const divElement = document.getElementById("pic");
                $('#exampleModal').toggle();
                // divElement.style.backgroundImage = "url(images/photo.png)";
                Swal.fire('Events are not saved', '', 'info')
              }
              else {
                Swal.fire({
                  icon: 'error',
                  title: 'Empty',
                  text: 'Fill out the form to Add event',
                  showConfirmButton: true,
                  allowOutsideClick: true
                })
              }
            });
     
   });



   function uploadpic() {
var file_data = $('#pics').prop('files')[0];
var form_data = new FormData();
form_data.append('file', file_data);
$.ajax({
  url: 'sql/uploadpayment.php',
  dataType: 'text',
  cache: false,
  contentType: false,
  processData: false,
  data: form_data,
  type: 'post',
  success: function (php_script_response) { }
});
};


    
$(".attendbtn").click(function (e) {
 
        // let latitude = "11.015916";
        // let longitude = "123.995585";
        
      var stid = $(this).data("stid");

      var eid = $(this).data("eventid");

        var evposlat = $(this).data('lati');
      var evposlng = $(this).data('longi');
      var start = $(this).data('timein');
      var out =  $(this).data('timeout');


      var currentime;
      var d = new Date();
      currentime = d.getHours() +":"+d.getMinutes();


        // start = ConvertTime(start);


        currentime =ConvertTime(currentime);

        console.log(currentime +" Timein: " + start + " Timeout: "+ out);


      if(currentime >= start  && currentime <= out){


        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function (pos) {
            //You have your locaton here

            
            var km = calculateDistance(
              pos.coords.latitude,
              pos.coords.longitude,
              evposlat,
              evposlng
            );

            // var km = calculateDistance(latitude, longitude, evposlat, evposlng);
              // console.log("My Location: " + pos.coords.latitude +" , "+ pos.coords.longitude);
              // console.log("My Event: " + evposlat +" , "+ evposlng);
              // console.log("Distance: " + km);

            if (km <= 0.1) {
              
                //take attendance

                $.ajax({
            url: "sql/takeattendance.php",
            type: "POST",
            data: {
              stid: stid,
              eventid: eid,
            }
          })
            .done(function (data) {
              let result = JSON.parse(data);
              if (result.res == "success") {
                Swal.fire({
                  icon: 'success',
                  title: 'Success',
                  text: 'Attendance Checked',
                  timer: 2000,
                  showConfirmButton: false,
                  allowOutsideClick: false,
                }).then((result) => {
                  if (result.dismiss === Swal.DismissReason.timer) {

                    location.reload();
                  }
                });

              }
              else if (result.res == "duplicate") {

                Swal.fire({
                  icon: 'info',
                  title: 'Duplicate Entry',
                  text: 'You have already taken the attendance',
                  showConfirmButton: true,
                  allowOutsideClick: true
                })


              }
              else {
                Swal.fire({
                  icon: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong',

                })
              }
            });


            } else if (km > 0.1) {

              Swal.fire({
                  icon: 'error',
                  title: 'You are not in the event place',
                  text: 'You are '+ Math.round(km * 1000) +' meters away',

                })
            } 
            else {
              Swal.fire({
                  icon: 'error',
                  title: 'Cant take the attendance',
                  text: 'Something went wrong',

                })
            }
          });
        } else {
          alert("Geolocation not supported");
        }
      }
      else{

        Swal.fire({
                  icon: 'error',
                  title: 'Cant take the attendance',
                  text: 'It is not time for attendance yet',

                })
      }

        // alert($(this).data('stid'));
      });



      function ConvertTime(timeStr){
    
            // Split the time into an array of hours and minutes.
      let [hours, minutes] = timeStr.split(":");
      // Convert the hours to a number.
      
      // If the hours are less than 12, add 12 to make them a 24-hour time.
      if (hours < 10) {
        hours = "0"+hours;
      }
      
      // Return the time in 24-hour format.
      return `${hours}:${minutes}`;
      }

      function calculateDistance(lat1, lon1, lat2, lon2) {
        const earthRadius = 6371; // Radius of the Earth in kilometers
        const dLat = deg2rad(lat2 - lat1);
        const dLon = deg2rad(lon2 - lon1);

        const a =
          Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos(deg2rad(lat1)) *
            Math.cos(deg2rad(lat2)) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);

        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const distance = earthRadius * c;
        return distance;
      }

      function deg2rad(degrees) {
        return degrees * (Math.PI / 180);
      }




      function logout(){
        location.href = "logout.php";
      }
  </script>

</body>

</html>