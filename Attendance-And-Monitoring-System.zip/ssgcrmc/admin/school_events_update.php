<?php
include "header.html"

  ?>
<?php

include './fragments/sidebar.php';
?>

<section class="home-section">
  <nav>
    <div class="sidebar-button">
      <i class="il uil-arrow-circle-left sidebarBtn"></i>
    </div>

    <div class="profile-details">
      <i class="uil uil-user-circle"></i>
      <i class="bx bx-chevron-down" onclick="toggleMenu()"></i>

      <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
          <div class="user-info">
            <i class="uil uil-user-circle user"></i>
            <h4>Admin Account</h4>
            <hr>
          </div>


          <a href="#" class="sub-menu-link">
            <i class="il uil-user-square usermenu"></i>
            <p>Profile</p>
          </a>
          <a href="logout.php" class="sub-menu-link">
            <i class="uil uil-signout usermenu"></i>
            <p>Log Out</p>
          </a>

        </div>
      </div>
    </div>
  </nav>

  <div class="home-content">
    <div class="overview-boxes">

      <div class="con">
        <i class="uil uil-notebooks"></i>
        <h3>Update School Events</h3>
      </div>
      <div class="containers py-5 aos-init aos-animate" style="width:1300px" data-aos="fade-up">
        <section id="book-a-table" class="book-a-table">
          <div class="row g-0">
            <?php
            include './sql/dbconnect.php';
            $location = 'images/';
            $sql = "SELECT * FROM event WHERE Id = '" . $_GET['id'] . "'";
            $stmt = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_object($stmt)) {
              ?>
              <div class="col-lg-4 col-md-6 reservation-img" id="pic"
                style="background-image: url(<?php echo $location . $row->img ?>)" data-aos="zoom-out" data-aos-delay="200">
              </div>
              <input type="file" name="pics" onchange="changeBackgroundImage(event)" id="pics" style="display:none;"
                accept="image/*">
              <div class="col-lg-8 d-flex align-items-center reservation-form-bg">
                <form action="#" method="post" role="form" class="add-form" data-aos="fade-up" data-aos-delay="100">
                  <div class="row gy-4">
                    <div class="col-lg-10 col-md-6">
                      <input type="text" name="name" class="form-control" id="what" placeholder="WHAT:"
                        value=" <?php echo $row->What ?>">
                      <input type="hidden" name="name" class="form-control" id="eId" placeholder="WHAT:"
                        value=" <?php echo $row->Id ?>">
                      <div class="validate"></div>

                    </div>
                    <div class="col-lg-10 col-md-6">
                      <input type="text" class="form-control" name="email" id="where" placeholder="WHERE:"
                        value="<?php echo $row->Where ?>">
                      <div class="validate"></div>
                    </div>
                    <div class="col-lg-10 col-md-6">
                      <input name="date" type="text" class="form-control" id="when" placeholder="WHEN:"
                        value=" <?php echo $row->When ?>" onfocus="(this.type='date')" />
                      <div class="validate"></div>
                    </div>
                    <div class="col-lg-10 col-md-6">

                      <input type="time" class="form-control" name="timestart" id="timestart"
                        value="<?php echo $row->timein ?>" placeholder="Sign in" required>
                      <br>
                      <input type="time" class="form-control" name="timeout" id="timeout"
                        value="<?php echo $row->timeout; ?>" placeholder="Sign out" required>
                    </div>
                    <div class="col-lg-10 col-md-6">
                      <p class="text-center">Input the Latitude and Longitude where the event will happen below.</p>

                      <input type="text" class="form-control" name="latitude" id="latitude"
                        value=" <?php echo $row->lati ?>" placeholder="Latitude 11.1245" required>
                      <br>
                      <input type="text" class="form-control" name="longitude" id="longitude"
                        value=" <?php echo $row->longi ?>" placeholder="Longitude 124.12345" required>
                    </div>
                  </div>



                </form>
              </div>
              <div style="position: relative; display: flex;justify-content:right;margin-top: 10px;"><button type="button"
                  class="btn btn-outline-warning fs-2" id="submit">Update Event</button></div>
              <div style="position: relative; display: flex;justify-content:right;margin-top: 10px;"><button type="button"
                  class="btn btn-outline-danger fs-2" id="delete">Delete Event</button></div>
            <?php } ?>
          </div>


        </section>
      </div>
    </div>
  </div>
</section>


<script>
  $("#pic").click(function () {
    document.querySelector("#pics").click();
  });

  function changeBackgroundImage(event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = function (e) {
      const imageUrl = e.target.result;
      document.getElementById('pic').style.backgroundImage = `url(${imageUrl})`;
    }

    reader.readAsDataURL(file);
  }

  $("#submit").click(function () {
    var up = $("#pics").val().length;
    if (up > '0') {

      var pic = $('#pics').val().replace(/.*(\/|\\)/, '');

    }
    else {
      var pic = '0';
    }
    var EId = document.querySelector("#eId").value;
    var What = document.querySelector("#what").value;
    var Where = document.querySelector("#where").value;
    var When = document.querySelector("#when").value;
    var tin = document.querySelector("#timestart").value;
    var tout = document.querySelector("#timeout").value;
    var lat = document.querySelector("#latitude").value;
    var lon = document.querySelector("#longitude").value;

    Swal.fire({ title: 'Do you really want to update this event?', showDenyButton: true, confirmButtonText: 'Yes', denyButtonText: `No`, }).then((result) => {
      if (result.isConfirmed && What != "" && Where != "" && When != "" & tin != "" && tout != "" && lat != "" && lon != "") {
        // send data to server
        $.ajax({
          url: "sql/update.event.php",
          type: "GET",
          data: {
            Id: EId,
            what: What,
            where: Where,
            when: When,
            timein: tin,
            timeout: tout,
            latitude: lat,
            longitude: lon,
            Pic: pic

          }
        })
          .done(function (data) {
            let result = JSON.parse(data);
            if (result.res == "success") {
              Swal.fire('Event Updated!', '', 'success')
              uploadpic();

            } else {
              alert("Error, Something happened!!!!");
              console.log(result.res);
            }
          });


      } else if (result.isDenied) {

        document.querySelector("form").reset();

        Swal.fire('Changes are not saved', '', 'info')
      }
    })
  });
  function uploadpic() {

    var file_data = $('#pics').prop('files')[0];
    var form_data = new FormData();
    form_data.append('file', file_data);
    $.ajax({
      url: 'sql/uploads.php',
      dataType: 'text',
      cache: false,
      contentType: false,
      processData: false,
      data: form_data,
      type: 'post',
      success: function (php_script_response) { }
    });
  }
  $("#delete").click(function () {
    var EId = document.querySelector("#eId").value;
    Swal.fire({ title: 'Do you really want to delete this event?', showDenyButton: true, confirmButtonText: 'Yes', denyButtonText: `No`, }).then((result) => {
      if (result.isConfirmed) {

        $.ajax({
          url: "sql/delete.events.php",
          type: "GET",
          data: {
            Id: EId
          }
        })
          .done(function (data) {
            let result = JSON.parse(data);
            if (result.res == "success") {
              window.location.href = "school_events.php";
            }

          });
      }
    });

  })


</script>
<?php
include "footer.html"

  ?>