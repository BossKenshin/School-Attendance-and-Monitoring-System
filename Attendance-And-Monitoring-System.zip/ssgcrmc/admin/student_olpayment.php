<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> CRMC SSG </title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg" />
    <link rel="stylesheet" href="adminstyles.css">

    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
   </head>
<body>
   
<?php

include './fragments/sidebar.php';
?>
 

  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='il uil-arrow-circle-left sidebarBtn'></i>
      </div>

      <div class="profile-details">
        <i class="uil uil-user-circle"></i>
        <i class="bx bx-chevron-down" onclick="toggleMenu()"></i>

      <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
          <div class="user-info">
          <i class="uil uil-user-circle user"></i> 
          <h4>Admin Account</h4>
          <hr>
          </div>
         

          <a href="user_profile.php" class="sub-menu-link">
          <i class="il uil-user-square usermenu"></i>
          <p>Profile</p>
          </a>
          <a href="admin_logout.php" class="sub-menu-link">
          <i class="uil uil-signout usermenu"></i>
          <p>Log Out</p>
          </a>

        </div>
      </div>

      </div> 
    </nav>

  

    <div class="home-content">
 
 <div class="overview-boxes">
  
   <div class="con">          
           <i class="uil uil-sign-alt"></i>
           <h3>Student Online Payment Information</h3>

           <!-- <label for="asd">Events</label>
           <select name="asd" id="asd" class="form-select w-25">
            <option value="">A</option>
            <option value="">B</option>
            <option value="">C</option>
            <option value="">D</option>
          </select> -->
           </div>

            <div class="containers py-5" style="width:1300px; height:600px; font-size: 13px; overflow-y: scroll; overflow-x:scroll; max-height:100vh">
            <div class="row">

          <table id="examples" class="table table-striped" style="width:100%">
         
          

          <thead style="color: black">
          
            <tr>
                <th style="text-align: center;"><b>ID</b></th>
                <th style="text-align: center"><b>STUDENT NAME</b></th>
                <th style="text-align: center"><b>STUDENT ID</b></th>
                <th style="text-align: center"><b>PROOF OF PAYMENT</b></th>
                <th style="text-align: center"><b>ACTION</b></th>
            </tr>
        </thead>
        <tbody>
          <style>
            td{
              text-align: left;
            }
          </style>
          <tr>
          <?php 
                          include './sql/dbconnect.php';

                            $sql = "SELECT `pay_id`,students.stid, firstname, lastname, student_id_no, `penaltyid`, `amount`, `image` FROM `onlinepayment` 
                            INNER JOIN students ON onlinepayment.stid = students.stid 
                            WHERE `pay_status` = 'unpaid';";
                            $stmt = mysqli_query($conn,$sql);
                            while($row = mysqli_fetch_object($stmt)){
                              ?>  
                                  <td><?= $row->stid ?></td>
                                  <td><?= $row->firstname.' '.$row->lastname?></td>
                                  <td><?= $row->student_id_no ?></td>
                                  <td><a href="<?php echo  "./paymentproof/".$row->image ?>"><?= $row->image ?></a></td>
                                  <td>
                                  <a href="<?php echo "./sql/verifyol.php?id=".$row->pay_id."&type=accept&penalty=".$row->penaltyid ?>" class='btn btn-success btn-sm b' data-toggle='modal'><i class='uil uil-check' style='color:white; font-size:15px; text-align: center'></i> Accept</a> |
                                  <a href="<?php echo "./sql/verifyol.php?id=".$row->pay_id."&type=deny&penalty=".$row->penaltyid."&stid=".$row->stid ?>" class='btn btn-danger btn-sm b' data-toggle='modal'><i class='uil uil-ban' style='color:white; font-size:15px; text-align: center'></i> Denied</a>
                                  </td>
                              </tr>
                              <?php } ?>
        </tbody>
      </table>
    </div>
</div>
    </div>  
  </section>

<script src="jquery/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="datatable/jquery.dataTables.min.js"></script>
<script src="datatable/dataTable.bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
<!-- <script src="script.js"></script> -->
  <script>
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
    sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("uil uil-angle-right");
}else
  sidebarBtn.classList.replace("uil uil-angle-right");
}
 </script>

<script>
  let subMenu = document.getElementById("subMenu");
  function toggleMenu(){
    subMenu.classList.toggle("open-menu");
  }
</script>

</body>
</html>
