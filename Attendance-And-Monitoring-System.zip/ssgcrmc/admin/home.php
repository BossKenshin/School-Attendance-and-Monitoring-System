<!DOCTYPE html>
<html lang="en" dir="ltr">

  <head>
    <meta charset="UTF-8">
    <title>  Online Voting </title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg" />
    <link rel="stylesheet" href="adminstyles.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.2/xlsx.full.min.js"
        integrity="sha512-qilAGdDSZ5c0sTjizcSCffmIb8D2rHttMYGUxtI3OFn8lB29BlU2tEUcPesHHLQ2t0Y5TInglWKY6V3GoSK0IA=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<style>
  .candidate {
    margin: auto;
    width: 23vw;
    padding: 0 10px;
    border-radius: 20px;
    margin-bottom: 1em;
    display: flex;
    border: 3px solid #00000008;
    background: #8080801a;

}
.candidate_name {
    margin: 8px;
    margin-left: 3.4em;
    margin-right: 3em;
    width: 100%;
}
	.img-field {
	    display: flex;
	    height: 8vh;
	    width: 4.3vw;
	    padding: .3em;
	    background: #80808047;
	    border-radius: 50%;
	    position: absolute;
	    left: -.7em;
	    top: -.7em;
	}
	
	.candidate img {
    height: 100%;
    width: 100%;
    margin: auto;
    border-radius: 50%;
}
.vote-field {
    position: absolute;
    right: 0;
    bottom: -.4em;
}
</style>
<body>
    
<?php


include('./sql/dbconnect.php') ;
include ('./fragments/sidebar.php');
	
$voting = $conn->query("SELECT * FROM voting_list where  is_default = 1 ");

$votes  = $conn->query("SELECT * FROM votes ");
$v_arr = array();
while($row=$votes->fetch_assoc()){
  if(!isset($v_arr[$row['voting_opt_id']]))
    $v_arr[$row['voting_opt_id']] = 0;

  $v_arr[$row['voting_opt_id']] += 1;
}
$opts = $conn->query("SELECT * FROM voting_opt ");
$opt_arr = array();
  while($row=$opts->fetch_assoc()){
  $opt_arr[$row['category_id']][] = $row;
  }
?>
 

  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='il uil-arrow-circle-left sidebarBtn'></i>
        
      </div>

      <div class="profile-details">
        <i class="uil uil-user-circle"></i>
        <i class="bx bx-chevron-down" onclick="toggleMenu()"></i>

      <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
          <div class="user-info">
          <i class="uil uil-user-circle user"></i> 
          <h6>Admin Account</h6>
          <hr>
          </div>


          <a href="user_profile.php" class="sub-menu-link">
          <i class="il uil-user-square usermenu"></i>
          <p>Profile</p>
          </a>
          <a href="admin_logout.php" class="sub-menu-link">
          <i class="uil uil-signout usermenu"></i>
          <p>Log Out</p>
          </a>

        </div>
      </div>

      </div> 
    </nav>

    <div class="home-content">
    <div class="dashboard">
      <br>
      <h4><b><u> Voting Dashboard</u></b>/ Admin Panel</h4>
      </div>
      <br><br>

      <div class="overview-boxes">
        <div class="box">
        <i class="uil uil-create-dashboard cart"></i>
          <div class="right-side">          
            <div class="box-topic">No. of Voters</div>
                  <div class="number"><?php echo $conn->query('SELECT * FROM students ')->num_rows ?></div>
            <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
            </div>
          </div>
        </div>
       
       

        <div class="box">
        <i class='uil uil-map-marker-plus cart four' ></i>
          <div class="right-side">
            <div class="box-topic">Voted</div>
               <div class="number"><?php echo $conn->query('SELECT distinct(stid) FROM votes ')->num_rows ?></div>
            <div class="indicator">
              <i class='bx bx-up-arrow-alt'></i>
           
            </div>
          </div>
          
        </div>
          
      
     
    </div>

	<div class="row mt-3 ml-3 mr-3">
			<div class="col-lg-12">
			<div class="card">
				<div class="card-body">
					<div class="text-center">
						<h3><b></b></h3>
						<small><b></b></small>	
					</div>
					<?php 
					$cats = $conn->query("SELECT * FROM category_list where id in (SELECT category_id from voting_opt)");
					while($row = $cats->fetch_assoc()):
					?>
						<hr>
						<div class="row mb-4">
							<div class="col-md-12">
									<div class="text-center">
										<h3><b><?php echo $row['category'] ?></b></h3>
									</div>
							</div>
						</div>
						<div class="row mt-3">
						<?php foreach ($opt_arr[$row['id']] as $candidate) {
						?>
							<div class="candidate" style="position: relative;">
								<div class="img-field">
									<img src="assets/img/<?php echo $candidate['image_path'] ?>" alt="">
								</div>
								<div class="candidate_name"><?php echo $candidate['Name'] ?></div>
								<div class="vote-field">
									<span class="badge badge-success"><large><b><?php echo isset($v_arr[$candidate['id']]) ? number_format($v_arr[$candidate['id']]) : 0 ?></b></large></span>
								</div>
							</div>
						<?php } ?>
						</div>
					<?php endwhile; ?>					
				</div>
			</div>
			
		</div>
		</div>
	</div>

</div> 
  </section>


<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
<script src="script.js"></script>

  <script>
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
      sidebarBtn.onclick = function() {
      sidebar.classList.toggle("active");
        if(sidebar.classList.contains("active")){
            sidebarBtn.classList.replace("uil uil-angle-right");
        }else
            sidebarBtn.classList.replace("uil uil-angle-right");
      }
 </script>

<script>
 

</script>

</body>
</html>
