<?php 

$conn= new mysqli('localhost','root','','crmcdb')or die("Could not connect to mysql".mysqli_error($con));
