<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> CRMC SSG </title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg" />
    <link rel="stylesheet" href="adminstyles.css">

    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

     <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.2/xlsx.full.min.js"
        integrity="sha512-qilAGdDSZ5c0sTjizcSCffmIb8D2rHttMYGUxtI3OFn8lB29BlU2tEUcPesHHLQ2t0Y5TInglWKY6V3GoSK0IA=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
   </head>
<body>
    
<?php

include './fragments/sidebar.php';
?>
 
 <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModal" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="editModal">Student Info</h1>
      </div>
      <div class="modal-body">
      <div class="containers py-5">
          <div class="row">
            <hr class="my-0" />
            <div class="card-body"><br>
              <form id="formAccountSettings" method="POST" onsubmit="return false">
              <input type="hidden" name="sid" id="sid">
                <div class="row">
                  <div class="mb-3 col-md-6">
                    <label for="firstName" class="form-label">Student Id No.</label>
                    <input class="form-control" type="text" id="stidno" name="stidno"
                      value="" autofocus />
                  </div>
                  <div class="mb-3 col-md-6">
                    <label for="firstname" class="form-label">Firstname</label>
                    <input class="form-control" type="text" name="firstname" id="firstname"
                      value="" />
                  </div>
                  <div class="mb-3 col-md-6">
                    <label for="lastname" class="form-label">Lastname</label>
                    <input class="form-control" type="text" id="lastname" name="lastname" value=""
                      placeholder="" />
                  </div>
                  <div class="mb-3 col-md-6">
                    <label for="email" class="form-label">Email</label>
                    <input type="text" class="form-control" id="email" name="email"
                      value="" />
                  </div>
                  <div class="mb-3 col-md-6">
                    <label for="gender" class="form-label">Gender</label>
                    <input type="text" class="form-control" id="gender" name="gender"
                      value="" />
                  </div>
                  <div class="mb-3 col-md-6">
                    <label for="course_and_year" class="form-label">Course & Year</label>
                    <input type="text" class="form-control" id="course_and_year" name="course_and_year"
                      value="" />
                  </div>
                  <div class="mb-3 col-md-6">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username"
                      value="" />
                  </div>
                  <div class="mb-3 col-md-6">
                    <label for="password" class="form-label">Password</label>
                    <input type="text" class="form-control" id="password" name="password"
                      value="" />
                  </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <div class="card">
        <h5 class="card-header">Delete Account</h5>
        <div class="card-body">
          <div class="mb-3 col-12 mb-0">
            <div class="alert alert-warning">
              <h6 class="alert-heading fw-bold mb-1">Are you sure you want to delete your account?</h6>
              <p class="mb-0">Once you delete your account, there is no going back. Please be certain.</p>
            </div>
          </div>
          <form id="formAccountDeactivation" onsubmit="return false">
            <div class="form-check mb-3">
            </div>
            <button type="submit" class="btn btn-danger deactivate-account" id="deleteaccount">Deactivate
              Account</button>
          </form>
        </div>
      </div>
    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="closemodal">Close</button>
        <button type="button" class="btn btn-primary" id="savechanges">Save changes</button>
      </div>
    </div>
  </div>
</div>


  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='il uil-arrow-circle-left sidebarBtn'></i>
      </div>


      <div class="profile-details">
        <i class="uil uil-user-circle"></i>
        <i class="bx bx-chevron-down" onclick="toggleMenu()"></i>

      <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
          <div class="user-info">
          <i class="uil uil-user-circle user"></i> 
          <h4>Admin Account</h4>
          <hr>
          </div>
         

          <a href="user_profile.php" class="sub-menu-link">
          <i class="il uil-user-square usermenu"></i>
          <p>Profile</p>
          </a>
          <a href="admin_logout.php" class="sub-menu-link">
          <i class="uil uil-signout usermenu"></i>
          <p>Log Out</p>
          </a>

        </div>
      </div>

      </div> 
    </nav>

  

    <div class="home-content">
    <div class="overview-boxes">
  
    <div class="containers py-5">
        <div>
            <label for="formFileLg" class="form-label">UPLOAD STUDENT INFORMATION EXCEL FILE<br><i>(Columns: ID Number,First Name, Last Name, Email, Course & Year )</i> </label>
            <input class="form-control form-control-lg" id="excelfile" type="file">  
        </div><br>
    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <button class="btn btn-primary me-md-2" type="button" id="addMultipleStudent">Upload</button>   
            </div>
        </div>

        <div class="con">          
           <i class="uil uil-sign-alt"></i>
           <h3>Student Information</h3>
           </div>

            <div class="containers py-5" style="width:1300px; height:600px; font-size: 13px; overflow-y: scroll; overflow-x:scroll; max-height:100vh">
            <div class="row">

          <table id="example1" class="table table-striped" style="width:100%">
          <thead style="color: black">
            <tr>
            <th style="text-align: center"><b>ID</b></th>
                <th style="text-align: center"><b>STUDENT NAME</b></th>
                <th style="text-align: center"><b>STUDENT ID</b></th>
                <th style="text-align: center"><b>COURSE & YEAR</b></th>
                <th style="text-align: center"><b>EMAIL</b></th>
                <th style="text-align: center"><b>GENDER</b></th>
                <th style="text-align: center"><b>USERNAME</b></th>
                <th style="text-align: center"><b>PASSWORD</b></th>
                <th style="text-align: center"><b>ACTION</b></th>

            </tr>
        </thead>
        <tbody>
          <style>
            td{
              text-align: left;
            }
          </style>
          <tr>
                          <?php 
                          include './sql/dbconnect.php';

                            $sql = "SELECT * FROM students";
                            $stmt = mysqli_query($conn,$sql);
                          
                            while($row = mysqli_fetch_object($stmt)){
                            ?>  
                                  
                                  <td><?= $row->stid ?></td>
                                  <td><?= $row->firstname.' '.$row->lastname?></td>
                                  <td><?= $row->student_id_no ?></td>
                                  <td><?= $row->course_year?></td>
                                  <td><?= $row->email?></td>
                                  <td><?= $row->gender?></td>
                                  <td><?= $row->st_username?></td>
                                  <td><?= $row->st_password?></td>
                                  <td>
                                    <button class="btn btn-success" onclick="openmodal(this.dataset.stid)" data-stid="<?= $row->stid; ?>" >EDIT</button>
                                  </td>
                              </tr>
                              <?php } ?>
        
                            </tbody>
      </table>
    </div>
</div>
    </div>  
  </section>
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="jquery/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="datatable/jquery.dataTables.min.js"></script>
<script src="datatable/dataTable.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
<!-- <script src="script.js"></script> -->
  <script>
   let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
    sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("uil uil-angle-right");
}else{
  sidebarBtn.classList.replace("uil uil-angle-right");
}}


function openmodal(element){

  // $(element).modal('show');
  $('#editModal').modal('show');
  var sid = element;



  $.ajax({
                                        url: "../admin/sql/fetch.student.php",
                                        type: "GET",
                                        data: {
                                            sid: sid,
                                        },
                                    }).done(function(result){

                                      let data = JSON.parse(result);           
                                      console.log(data);
                                      $('#sid').val(sid);                           
                                      $('#stidno').val(data[0].student_id_no);
                                      $('#firstname').val(data[0].firstname);
                                      $('#lastname').val(data[0].lastname);
                                      $('#email').val(data[0].email);
                                      $('#gender').val(data[0].gender);
                                      $('#course_and_year').val(data[0].course_year);
                                      $('#username').val(data[0].st_username);
                                      $('#password').val(data[0].st_password);
                                    })

  

}


$('#savechanges').click(function(){

  var datas = $( "#formAccountSettings" ).find( "input[type='text']" );
  var golang;
for(var i = 0; i < datas.length; i++){
      if(datas[i].value == ""){
        Swal.fire({
                                            icon: 'error',
                                            title: 'Fill out all fields',
                                            showConfirmButton: true,
                                          })
        golang = false;
        break;
      }
      else{
        golang = true;
      }
    }

            if(golang == true){
                              $.ajax({
                                        url: "../admin/sql/update.student.php",
                                        type: "GET",
                                        data: {
                                            sid: $('#sid').val(),
                                            stidno: $('#stidno').val(),
                                            fn:$('#firstname').val(),
                                            ln:$('#lastname').val(),
                                            email:$('#email').val(),
                                            gender:$('#gender').val(),
                                            cny:$('#course_and_year').val(),
                                            username: $('#username').val(),
                                            password: $('#password').val()
                                        },
                                    }).done(function(result){
                                      let res = JSON.parse(result);
                                      if(res.res == 'success'){
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Student Info updated successfully',
                                            showConfirmButton: false,
                                            allowOutsideClick: false,
                                            timer: 2000
                                          })
                                          .then((result) => {
                                                /* Read more about handling dismissals below */
                                                if (result.dismiss === Swal.DismissReason.timer) {
                                                  location.reload();
                                                }
                                              })
                                      }
                                      else{
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Something went wrong',
                                            showConfirmButton: true,
                                          })
                                      }
                                    
                                    })
                                  }

});



$('#closemodal').click(function(){
  $('#editModal').modal('hide');
  $("#formAccountSettings").find("input[type=text]").val("");


});


$('#deleteaccount').click(function (){

  $.ajax({
                                        url: "../admin/sql/delete.student.php",
                                        type: "GET",
                                        data: {
                                            sid: $('#sid').val()
                                        },
                                    }).done(function(result){
                                      let res = JSON.parse(result);
                                      if(res.res == 'success'){
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Student Info deleted successfully',
                                            showConfirmButton: false,
                                            allowOutsideClick: false,
                                            timer: 2000
                                          })
                                          .then((result) => {
                                                /* Read more about handling dismissals below */
                                                if (result.dismiss === Swal.DismissReason.timer) {
                                                  location.reload();
                                                }
                                              })
                                      }
                                      else{
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Something went wrong',
                                            showConfirmButton: true,
                                          })
                                      }
                                    
                                    })
                                    
})



 </script>

<script>
  let subMenu = document.getElementById("subMenu");
  function toggleMenu(){
    subMenu.classList.toggle("open-menu");
  }
</script>

<script>
        let selectedFile;
        var DBstudentObject;
        var rowStudentList;

        document
            .getElementById("excelfile")
            .addEventListener("change", (event) => {
                selectedFile = event.target.files[0];
            });

        document
            .getElementById("addMultipleStudent")
            .addEventListener("click", () => {
                //  let rowObject;
                if (selectedFile) {
                    let fileReader = new FileReader();
                    fileReader.readAsBinaryString(selectedFile);
                    fileReader.onload = (event) => {
                        let data = event.target.result;
                        let workbook = XLSX.read(data, { type: "binary" });
                        workbook.SheetNames.forEach((sheet) => {
                            rowStudentList = XLSX.utils.sheet_to_row_object_array(
                                workbook.Sheets[sheet]
                            );
                        });

                        var regExp = /[a-zA-Z]/;
                        var len = rowStudentList.length;
                        var _hasrun = false;
                        for (var i = 0; i < rowStudentList.length; i++) {
                        var randomUsername = generateRandomUsername(); // Generate a random username with 8 characters
                        var randomPassword = generateRandomPassword();
                            if (rowStudentList[i].hasOwnProperty("ID Number") && rowStudentList[i].hasOwnProperty("First Name") && rowStudentList[i].hasOwnProperty("Last Name") && rowStudentList[i].hasOwnProperty("Email") && rowStudentList[i].hasOwnProperty("Gender")) {
                                if (!regExp.test(rowStudentList[i]['ID Number'])) {
                                    $.ajax({
                                        url: "../admin/sql/add.student.php",
                                        type: "GET",
                                        data: {
                                            sid: rowStudentList[i]['ID Number'],
                                            sfn: rowStudentList[i]['First Name'],
                                            sln: rowStudentList[i]['Last Name'],
                                            email: rowStudentList[i]['Email'],
                                            gen: rowStudentList[i]['Gender'],
                                            cny: rowStudentList[i]['Course & Year'],
                                            user: randomUsername,
                                            pass: randomPassword,
                                        },
                                    }).done(function () {
                                        if ((i = len)) {
                                            if (_hasrun === false) {
                                                // $("#studentTable").DataTable().clear().destroy();
                                                // setStudentTable();
                                                /*RERUN THE FETCHING OF DATA AFTER NEW DATA ADDED */
                                                _hasrun = true;
                                                Swal.fire({
                                            position: 'top-end',
                                            icon: 'success',
                                            title: 'Data saved to Database',
                                            showConfirmButton: false,
                                            allowOutsideClick: false,
                                            timer: 1000
                                          })
                                          .then((result) => {
                                                /* Read more about handling dismissals below */
                                                if (result.dismiss === Swal.DismissReason.timer) {
                                                  location.reload();
                                                }
                                              })
                                            }
                                        }
                                    });
                                }
                            } else {
                                /*ALERT FUNCTION IF THE FILE IS WRONG */
                                Swal.fire(
                                  'WRONG/MISSING FILE!',
                                  'Attach the correct file',
                                  'information'
                                )
                                // Swal.fire({
                                // icon: "Error",
                                // title: "Oops...",
                                // text: "You have selected a wrong file",
                                // });
                            }
                        }
                        document.querySelector("#excelfile").value = "";
                    };
                } else {
                    /*ALERT FUNCTION IF MISSING A FILE ON SUBMIT */
                    // alert("No File");
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Please attach the file!!",
                    });
                }
            });




        function generateRandomUsername() {
            const characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            let username = '';

            for (let i = 0; i < 8; i++) {
                const randomIndex = Math.floor(Math.random() * characters.length);
                username += characters.charAt(randomIndex);
            }

            return username;
        }

        function generateRandomPassword() {
            const characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#&()';
            let password = '';

            for (let i = 0; i < 8; i++) {
                const randomIndex = Math.floor(Math.random() * characters.length);
                password += characters.charAt(randomIndex);
            }

            return password;
        }

        // Usage example:
         // Generate a random password with 10 characters

        // console.log('Random Username:', randomUsername);
        // console.log('Random Password:', randomPassword);

    </script>
</body>
</html>
