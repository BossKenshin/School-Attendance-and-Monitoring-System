<?php

require "sql/dbconnect.php";
session_start();

$adminid = $_SESSION['admin_uid'];

if (!isset($_SESSION['admin_uid'])) {
  header("location: ../index.php");
}


$admin = "SELECT * FROM admin WHERE id = '$adminid';";
$qr = mysqli_query($conn, $admin);

$row = mysqli_fetch_assoc($qr);

$fullname = $row['fullname'];
$password = $row['password'];
$email = $row['email'];
$position = $row['position'];

$image;

if ($row['user_image'] != null) {
  $image = $row['user_image'];

} else {
  $image = "admin.png";
}





?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> CRMC SSG </title>
  <link rel="icon" type="image/x-icon" href="images/logo.jpg" />
  <link rel="stylesheet" href="adminstyles.css">

  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body>

  <?php

  include './fragments/sidebar.php';
  ?>


  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='il uil-arrow-circle-left sidebarBtn'></i>
      </div>


      <div class="profile-details">
        <i class="uil uil-user-circle"></i>
        <i class="bx bx-chevron-down" onclick="toggleMenu()"></i>

        <div class="sub-menu-wrap" id="subMenu">
          <div class="sub-menu">
            <div class="user-info">
              <i class="uil uil-user-circle user"></i>
              <h4>Admin Account</h4>
              <hr>
            </div>


            <a href="user_profile.php" class="sub-menu-link">
              <i class="il uil-user-square usermenu"></i>
              <p>Profile</p>
            </a>
            <a href="admin_logout.php" class="sub-menu-link">
              <i class="uil uil-signout usermenu"></i>
              <p>Log Out</p>
            </a>

          </div>
        </div>

      </div>
    </nav>



    <div class="home-content">

      <div class="overview-boxes">

        <div class="con">
          <i class="uil uil-sign-alt"></i>
          <h3>Account Setting / My profile</h3>
        </div>

        <div class="containers py-5">
          <div class="row">
            <div class="card-body">
              <div class="d-flex align-items-start align-items-sm-center gap-4">
                <img src="assets/img/<?php echo $image; ?>" alt="user-avatar" class="d-block rounded" height="100"
                  width="100" id="uploadedAvatar" />
                <div class="button-wrapper">
                  <label for="upload" class="btn btn-primary me-2 mb-4" tabindex="0">
                    <span class="d-none d-sm-block">Upload new photo</span>
                    <i class="bx bx-upload d-block d-sm-none"></i>
                    <input type="file" id="upload" class="account-file-input" hidden accept="image/png, image/jpeg" />
                  </label>
                  <button type="button" class="btn btn-outline-secondary account-image-reset mb-4">
                    <i class="bx bx-reset d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Reset</span>
                  </button>
                  <p class="text-muted mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                </div>
              </div>
            </div>
            <hr class="my-0" />
            <div class="card-body"><br>
              <form id="formAccountSettings" method="POST" onsubmit="return false">
                <div class="row">
                  <div class="mb-3 col-md-6">
                    <label for="firstName" class="form-label">Full Name</label>
                    <input class="form-control" type="text" id="fullname" name="fullname"
                      value="<?php echo $fullname ?>" autofocus />
                  </div>
                  <div class="mb-3 col-md-6">
                    <label for="lastName" class="form-label">Password</label>
                    <input class="form-control" type="text" name="password" id="password"
                      value="<?php echo $password ?>" />
                  </div>
                  <div class="mb-3 col-md-6">
                    <label for="email" class="form-label">E-mail</label>
                    <input class="form-control" type="text" id="email" name="email" value="<?php echo $email ?>"
                      placeholder="" />
                  </div>
                  <div class="mb-3 col-md-6">
                    <label for="organization" class="form-label">Position</label>
                    <input type="text" class="form-control" id="position" name="position"
                      value="<?php echo $position ?>" />
                  </div>
                  <div class="mt-2">
                    <button type="submit" class="btn btn-primary me-2" id="savechanges">Save changes</button>
                    <button type="submit" class="btn btn-success me-2" id="addnew">Add as New</button>
                    <button type="reset" class="btn btn-outline-secondary" id="canceluser">Cancel</button>
                  </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <div class="card">
        <h5 class="card-header">Delete Account</h5>
        <div class="card-body">
          <div class="mb-3 col-12 mb-0">
            <div class="alert alert-warning">
              <h6 class="alert-heading fw-bold mb-1">Are you sure you want to delete your account?</h6>
              <p class="mb-0">Once you delete your account, there is no going back. Please be certain.</p>
            </div>
          </div>
          <form id="formAccountDeactivation" onsubmit="return false">
            <div class="form-check mb-3">
            </div>
            <button type="submit" class="btn btn-danger deactivate-account" id="deleteaccount">Deactivate
              Account</button>
          </form>
        </div>
      </div>
    </div>
    </div>
  </section>

  <script src="jquery/jquery.min.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>
  <script src="datatable/jquery.dataTables.min.js"></script>
  <script src="datatable/dataTable.bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
  <script src="script.js"></script>
  <script>

    $('#savechanges').click(function () {

      var formdata = new FormData();

      var file = $('#upload').prop('files')[0];

      var fullname = $('#fullname').val();
      var password = $('#password').val();
      var position = $('#position').val();
      var email = $('#email').val();
      var adminid = $('#adminid').val();



      if (file) {
        formdata.append('image', file);
        formdata.append('isImage', true);
      }
      else {
        formdata.append('isImage', false);
      }

      formdata.append('name', fullname);
      formdata.append('password', password);
      formdata.append('position', position);
      formdata.append('email', email);



      $.ajax({
        url: "sql/update.admin.php",
        type: "POST",
        data: formdata,
        processData: false,
        contentType: false,
      })
        .done(function (data) {

          let result = JSON.parse(data);

          if (result.res == "success") {


            Swal.fire({
              icon: 'success',
              title: 'Success',
              text: 'Admin Updated',
              timer: 2000,
              showConfirmButton: false,
              allowOutsideClick: false
            }).then((result) => {

              if (result.dismiss === Swal.DismissReason.timer) {
                location.reload();
              }
            })

          }
          else {
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Something went wrong',

            })
          }
        });
    });





    $('#addnew').click(function () {

      var formdata = new FormData();

      var file = $('#upload').prop('files')[0];

      var fullname = $('#fullname').val();
      var password = $('#password').val();
      var position = $('#position').val();
      var email = $('#email').val();
      var adminid = $('#adminid').val();



      if (file) {
        formdata.append('image', file);
        formdata.append('isImage', true);
      }
      else {
        formdata.append('isImage', false);
      }

      formdata.append('name', fullname);
      formdata.append('password', password);
      formdata.append('position', position);
      formdata.append('email', email);



      $.ajax({
        url: "sql/add.admin.php",
        type: "POST",
        data: formdata,
        processData: false,
        contentType: false,
      })
        .done(function (data) {

          let result = JSON.parse(data);

          if (result.res == "success") {


            Swal.fire({
              icon: 'success',
              title: 'Success',
              text: 'Admin added successfully',
              timer: 2000,
              showConfirmButton: false,
              allowOutsideClick: false
            }).then((result) => {

              if (result.dismiss === Swal.DismissReason.timer) {
                location.reload();
              }
            })

          }
          else {
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'Something went wrong',

            })
          }
        });




    });


    $('#deleteaccount').click(function () {


      Swal.fire({ title: 'Do you really want to deactivate this account?', showDenyButton: true, confirmButtonText: 'Yes', denyButtonText: `No`, })
        .then((result) => {
          if (result.isConfirmed) {




            $.ajax({
              url: "sql/deact.admin.php",
              type: "POST",
              data: {
                val: "delete"
              },
            })
              .done(function (data) {

                let result = JSON.parse(data);

                if (result.res == "success") {


                  Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Account Deactivated',
                    timer: 2000,
                    showConfirmButton: false,
                    allowOutsideClick: false
                  }).then((result) => {

                    if (result.dismiss === Swal.DismissReason.timer) {
                      location.href = "../index.php";
                    }
                  })

                }
                else {
                  Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong',

                  })
                }
              });

          }

        });




    });



    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
    sidebarBtn.onclick = function () {
      sidebar.classList.toggle("active");
      if (sidebar.classList.contains("active")) {
        sidebarBtn.classList.replace("uil uil-angle-right");
      } else
        sidebarBtn.classList.replace("uil uil-angle-right");
    }
  </script>

  <script>
    let subMenu = document.getElementById("subMenu");
    function toggleMenu() {
      subMenu.classList.toggle("open-menu");
    }
  </script>

</body>

</html>