<?php
require "dbconnect.php";
session_start();

$event_id = $_GET['ID'];
$st_id = $_GET['St_ID'];


   
     $sql = "UPDATE `event_penalty` SET `Status`='Paid' WHERE student_Id = '$st_id' AND event_Id = '$event_id'";
    $res = mysqli_query($conn,$sql);
    if($res){
        echo "{\"res\" : \"success\"}";
    }else{
       echo "{\"res\" : \"error\"}";
    }

    ?>