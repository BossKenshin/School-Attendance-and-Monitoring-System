<?php
  require "dbconnect.php";

 
    $myArray = array();
    $sql =  "SELECT students.stid,students.student_id_no,CONCAT(students.firstname,' ',students.lastname) As Name,students.course_year,event.Id,event.What,event.When,event_attendance.student_Id,event_attendance.event_Id,event_attendance.Status FROM event_attendance INNER JOIN event ON event_attendance.event_Id=event.Id INNER JOIN students ON event_attendance.student_Id = students.stid WHERE event_attendance.Status ='Inactive' AND event.Id = '".$_GET['Id']."'";
    $res = mysqli_query($conn,$sql);

    while($row = $res->fetch_assoc()) {
        $myArray[] =$row;
    }
    
    echo json_encode($myArray);
    ?>