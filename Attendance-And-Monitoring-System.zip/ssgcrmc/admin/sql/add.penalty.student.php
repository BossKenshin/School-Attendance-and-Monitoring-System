<?php
require "dbconnect.php";

$Penalty = $_GET['Penalty'];
$event_Id = $_GET['Id'];

$sql2 = "SELECT * FROM `event_attendance` WHERE `event_Id` = '$event_Id' && Status = 'Inactive'";
$res2 = mysqli_query($conn,$sql2);

while($row = mysqli_fetch_object($res2))
    {
        $eveID = $row->event_Id;
        $stID = $row->student_Id;



        $sql = "INSERT INTO `event_penalty`(`student_Id`, `event_Id`, `penalty`) VALUES ('$stID','$eveID','$Penalty')";
        $res = mysqli_query($conn,$sql);   

  }
                if($res){
                    echo "{\"res\" : \"success\"}";
                    }else{
                    echo "{\"res\" : \"error\"}";
                    }






?>