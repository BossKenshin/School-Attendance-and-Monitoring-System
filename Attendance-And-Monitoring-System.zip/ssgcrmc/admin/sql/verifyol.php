<?php 

include '../sql/dbconnect.php';



mysqli_begin_transaction($conn);

try {

    $pid = $_GET['id'];

    if($_GET['type'] == "accept"){


    $peid = $_GET['penalty'];


    $stmt = mysqli_prepare($conn, "UPDATE onlinepayment SET pay_status = 'paid' WHERE pay_id = '$pid'");
    mysqli_stmt_execute($stmt);

    $stmt1 = mysqli_prepare($conn, "UPDATE `event_penalty` SET `Status`='Paid' WHERE Id = '$peid'");
    mysqli_stmt_execute($stmt1);
    }
    else{

        $peid = $_GET['penalty'];
        $stid = $_GET['stid'];
        
        
     $sql1 = "UPDATE `event_penalty` SET `Status`='Unpaid' WHERE student_Id = '$stid' AND Id = '$peid'";
     $res1 = mysqli_query($conn,$sql1);


        $stmt = mysqli_prepare($conn, "DELETE FROM onlinepayment WHERE pay_id = '$pid'");
        mysqli_stmt_execute($stmt);
    
    }

    /* If code reaches this point without errors then commit the data in the database */
    mysqli_commit($conn);
    header("location: ../student_olpayment.php");
} catch (mysqli_sql_exception $exception) {
    mysqli_rollback($conn);

    header("location: ../student_olpayment.php");
}


                        ?>