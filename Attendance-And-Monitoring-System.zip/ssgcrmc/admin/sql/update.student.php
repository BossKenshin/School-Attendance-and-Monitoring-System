<?php 
require "dbconnect.php";

$stid = $_GET['sid'];
$stidno = $_GET['stidno'];
$fn = $_GET['fn'];
$ln = $_GET['ln'];
$email = $_GET['email'];
$gender = $_GET['gender'];
$cny = $_GET['cny'];
$username = $_GET['username'];
$password = $_GET['password'];



$update = "UPDATE `students` SET `student_id_no`='$stidno',`firstname`='$fn',`lastname`='$ln',`email`='$email',`gender`='$gender',`course_year`='$cny',`st_username`='$username',`st_password`='$password' WHERE `stid` = '$stid'";

$result = mysqli_query($conn,$update);

if($result){
    echo "{\"res\" : \"success\"}";
}else{
   echo "{\"res\" : \"error\"}";
}

?>