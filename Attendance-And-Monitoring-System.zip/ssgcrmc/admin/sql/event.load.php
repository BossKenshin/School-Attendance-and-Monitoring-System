<?php
  require "dbconnect.php";

    //create array
    $myArray = array();

    $sql = "Select * FROM event WHERE status = 'Active'";
    $res = mysqli_query($conn,$sql);

    while($row = $res->fetch_assoc()) {
        $myArray[] = $row;
    }
    
    echo json_encode($myArray);
    ?>