<?php
require "dbconnect.php";

$id = $_GET['sid'];
$students = "SELECT * FROM students WHERE stid = '$id';";

$query = mysqli_query($conn,$students);
$data = array();

while($row = mysqli_fetch_object($query)){
        $data[] = $row;
}

echo json_encode($data);

?>