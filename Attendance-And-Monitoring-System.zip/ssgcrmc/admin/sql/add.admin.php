<?php
require "dbconnect.php";
session_start();
$uploads_dir = "../assets/img";

$res;
$name = $_POST['name'];
$password = $_POST['password'];
$email = $_POST['email'];
$position = $_POST['position'];
$adminid = $_SESSION['admin_uid'];



if($_POST['isImage'] == "true"){


    $tmp_name = $_FILES["image"]["tmp_name"];
    // basename() may prevent filesystem traversal attacks;
    // further validation/sanitation of the filename may be appropriate
    $image = basename($_FILES["image"]["name"]);
    $imagename = $_FILES["image"]["name"];
    
    
            $sql = "INSERT INTO `admin`(`fullname`, `email`, `user_image`, `position`, `password`) VALUES ('$name','$email','$imagename','$position','$password')";
            $res = mysqli_query($conn,$sql);   
            move_uploaded_file($tmp_name, "$uploads_dir/$image");
}
else{

    $sql = "INSERT INTO `admin`(`fullname`, `email`, `position`, `password`) VALUES ('$name','$email','$position','$password')";
    $res = mysqli_query($conn,$sql);   
}

if($res){

    echo "{\"res\" : \"success\"}";
    }else{
    echo "{\"res\" : \"error\"}";
    }

                

?>