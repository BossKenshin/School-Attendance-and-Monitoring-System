<?php

require "dbconnect.php";
session_start();

extract($_POST);
$id = $_SESSION['student_uid'];
$data = extract($_POST);

if($data == 11){

$president = "INSERT INTO `votes`(`category_id`, `voting_opt_id`, `stid`)
 VALUES ('1','$President','$id'),
 ('2','$VicePresident','$id'),
 ('3','$Secretary','$id'),
 ('4','$Treasurer','$id'),
 ('5','$Auditor','$id'),
 ('6','$PublicInformationOfficer','$id'),
 ('7','$PeaceOfficer','$id'),
 ('8','$FirstYearRepresentative','$id'),
 ('9','$SecondYearRepresentative','$id'),
 ('10','$ThirdYearRepresentative','$id'),
 ('11','$FourthYearRepresentative','$id');";
$query = mysqli_query($conn, $president);
if ($query) {
    echo 0;
} else {
    echo 1;
}
}
else if($data < 11){
    echo 3;
}
else{
    echo 4;
}




?>