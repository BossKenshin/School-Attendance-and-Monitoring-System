<?php
  require "dbconnect.php";

  $id = $_POST['canid'];
    //create array
    $myArray = array();

    $sql = "Select * FROM voting_opt WHERE id = '$id'";
    $res = mysqli_query($conn,$sql);

    while($row = $res->fetch_assoc()) {
        $myArray[] = $row;
    }
    
    echo json_encode($myArray);
    ?>