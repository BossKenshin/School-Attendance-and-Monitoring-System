<?php
require "dbconnect.php";
$wat = $_GET['what'];
$wer = $_GET['where'];
$wen = $_GET['when'];
$pic = $_GET['Pic'];
$Id = $_GET['Id'];
$timein = $_GET['timein'];
$timeout = $_GET['timeout'];
$latitude = $_GET['latitude'];
$longitude = $_GET['longitude'];

if($pic == '' || $pic == '0'){
    $pic = "chefs-1.jpg";
}

    $sql = "UPDATE `event` SET `What`='$wat',`Where`='$wer',`When`='$wen',`img`='$pic',`timein`='$timein',`timeout`='$timeout',`longi`='$longitude',`lati`='$latitude'  WHERE Id = '$Id'";
    $res = mysqli_query($conn,$sql);

     if($res){
        echo "{\"res\" : \"success\"}";
    }else{
        echo "{\"res\" : \"error\"}";
    }
?>
