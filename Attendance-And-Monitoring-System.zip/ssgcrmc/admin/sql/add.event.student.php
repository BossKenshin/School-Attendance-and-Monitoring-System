<?php
require "dbconnect.php";


$wat = $_GET['what'];

$sql1 = "SELECT * FROM `event` WHERE `What`='$wat'";
$res1 = mysqli_query($conn,$sql1);
$row1 = mysqli_fetch_object($res1);
$ID = $row1->Id;

$sql2 = "SELECT * FROM `students`";
$res2 = mysqli_query($conn,$sql2);

while($row = mysqli_fetch_object($res2))
    {
        $stID = $row->stid;

        $sql = "INSERT INTO `event_attendance`(`student_Id`, `event_Id`) VALUES ('$stID','$ID')";
        $res = mysqli_query($conn,$sql);   

  }

  if($res){
    echo "{\"res\" : \"success\"}";
}else{
   echo "{\"res\" : \"error\"}";
}




?>