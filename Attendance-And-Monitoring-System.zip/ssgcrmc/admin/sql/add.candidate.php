<?php
require "dbconnect.php";

$uploads_dir = "../assets/img";

$tmp_name = $_FILES["image"]["tmp_name"];
// basename() may prevent filesystem traversal attacks;
// further validation/sanitation of the filename may be appropriate
$image = basename($_FILES["image"]["name"]);

$imagename = $_FILES["image"]["name"];
$categoryid = $_POST['position'];
$name = $_POST['name'];


        $sql = "INSERT INTO `voting_opt`(`category_id`, `image_path`, `Name`) VALUES ('$categoryid','$imagename','$name')";
        $res = mysqli_query($conn,$sql);   

                if($res){
                    move_uploaded_file($tmp_name, "$uploads_dir/$image");

                    echo "{\"res\" : \"success\"}";
                    }else{
                    echo "{\"res\" : \"error\"}";
                    }






?>