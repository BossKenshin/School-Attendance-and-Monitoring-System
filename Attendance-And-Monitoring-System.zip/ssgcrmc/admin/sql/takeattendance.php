<?php
require "dbconnect.php";


$student_id = $_POST['stid'];
$event_id = $_POST['eventid'];


$check = "SELECT * FROM event_attendance WHERE student_Id = '$student_id' AND event_Id = '$event_id' AND Status = 'Active'";
$resultcheck = mysqli_query($conn,$check);


if(mysqli_num_rows($resultcheck) == 0){

    // $insert = "INSERT INTO event_attendance (student_Id, event_Id) VALUES('$student_id','$event_id')";
    $insert = "UPDATE event_attendance SET Status='Active' WHERE student_Id = '$student_id' AND event_Id = '$event_id'";
    $query = mysqli_query($conn,$insert);

    if($query){
        echo "{\"res\" : \"success\"}";
    }
    else{
        echo "{\"res\" : \"error\"}";
    }

}
else{
    echo "{\"res\" : \"duplicate\"}";
}



?>