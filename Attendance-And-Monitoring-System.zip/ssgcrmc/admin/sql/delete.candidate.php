<?php
require "dbconnect.php";

$id = $_POST['canid'];

        $sql = "DELETE FROM `voting_opt` WHERE id = '$id'";
        $res = mysqli_query($conn,$sql);   

                if($res){

                    echo "{\"res\" : \"success\"}";
                    }else{
                    echo "{\"res\" : \"error\"}";
                    }


?>