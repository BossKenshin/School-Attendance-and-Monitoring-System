<?php
require "dbconnect.php";
session_start();

$penal_id = $_GET['ID'];
$event_id = $_GET['Event'];
$amount = $_GET['pAmount'];
$pic = $_GET['Pic'];
   
     $sql1 = "UPDATE `event_penalty` SET `Status`='Pending' WHERE student_Id = '".$_SESSION['student_uid']."' AND event_Id = '$event_id'";
    $res1 = mysqli_query($conn,$sql1);


    $sql = "INSERT INTO `onlinepayment`(`stid`, `penaltyid`, `amount`, `image`) VALUES ('".$_SESSION['student_uid']."','$penal_id','$amount','$pic')";
    $res = mysqli_query($conn,$sql);

    if($res){
        echo "{\"res\" : \"success\"}";
    }else{
       echo "{\"res\" : \"error\"}";
    }

    ?>