<?php
require "dbconnect.php";
session_start();
$uploads_dir = "../assets/img";

$res;
$name = $_POST['name'];
$password = $_POST['password'];
$email = $_POST['email'];
$position = $_POST['position'];
$adminid = $_SESSION['admin_uid'];



if($_POST['isImage'] == "true"){


    $tmp_name = $_FILES["image"]["tmp_name"];
    // basename() may prevent filesystem traversal attacks;
    // further validation/sanitation of the filename may be appropriate
    $image = basename($_FILES["image"]["name"]);
    $imagename = $_FILES["image"]["name"];
    
    
            $sql = "UPDATE `admin` SET  `fullname`='$name',`email`='$email',`user_image`='$imagename',`position`='$position',`password`='$password' WHERE id = '$adminid'";
            $res = mysqli_query($conn,$sql);   
            move_uploaded_file($tmp_name, "$uploads_dir/$image");
}
else{

    $sql = "UPDATE `admin` SET  `fullname`='$name',`email`='$email',`position`='$position',`password`='$password' WHERE id = '$adminid'";
    $res = mysqli_query($conn,$sql);   
}

if($res){

    echo "{\"res\" : \"success\"}";
    }else{
    echo "{\"res\" : \"error\"}";
    }

                

?>