<?php
require "dbconnect.php";
$event_Id = $_GET['Id'];
    $sql = "UPDATE `event` SET status='Inactive' WHERE Id = '$event_Id'";
    $res = mysqli_query($conn,$sql);

     if($res){
        echo "{\"res\" : \"success\"}";
    }else{
        echo "{\"res\" : \"error\"}";
    }
?>
