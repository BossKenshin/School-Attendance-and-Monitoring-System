<?php
require "dbconnect.php";

$uploads_dir = "../assets/img";

$res;
$categoryid = $_POST['position'];
$name = $_POST['name'];
$candidateid = $_POST['candid'];

if($_POST['isImage'] == "true"){


    $tmp_name = $_FILES["image"]["tmp_name"];
    // basename() may prevent filesystem traversal attacks;
    // further validation/sanitation of the filename may be appropriate
    $image = basename($_FILES["image"]["name"]);
    $imagename = $_FILES["image"]["name"];
    
    
            $sql = "UPDATE `voting_opt` SET category_id = '$categoryid', image_path = '$imagename', Name = '$name' WHERE id = '$candidateid';";
            $res = mysqli_query($conn,$sql);   
            move_uploaded_file($tmp_name, "$uploads_dir/$image");
}
else{

    $sql = "UPDATE `voting_opt` SET category_id = '$categoryid', Name = '$name' WHERE id = '$candidateid';";
    $res = mysqli_query($conn,$sql);   
}

if($res){

    echo "{\"res\" : \"success\"}";
    }else{
    echo "{\"res\" : \"error\"}";
    }

                

?>