<?php
    require "dbconnect.php";
    
$Id = $_GET['Id'];

    $sql = "UPDATE `event` SET `status`='Hidden ' WHERE Id = '$Id'";
    $res = mysqli_query($conn,$sql);

     if($res){
        echo "{\"res\" : \"success\"}";
    }else{
        echo "{\"res\" : \"error\"}";
    }
?>