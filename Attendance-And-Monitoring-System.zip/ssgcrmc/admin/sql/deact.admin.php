<?php

require "dbconnect.php";
session_start();

$id = $_SESSION['admin_uid'];

$deact = "DELETE FROM admin where id = '$id'";
$d = mysqli_query($conn, $deact);


if($d){

    echo "{\"res\" : \"success\"}";
    session_unset();

    }else{
    echo "{\"res\" : \"error\"}";
    }












?>