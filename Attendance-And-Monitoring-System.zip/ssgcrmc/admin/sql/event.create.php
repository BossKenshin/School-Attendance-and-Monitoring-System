<?php

require "dbconnect.php";
    // ob_start();
    // session_start();

$wat = $_GET['what'];
$wer = $_GET['where'];
$wen = $_GET['when'];
$timein = $_GET['timein'];
$timeout = $_GET['timeout'];
$latitude = $_GET['latitude'];
$longitude = $_GET['longitude'];
$pic = $_GET['Pic'];

if($pic == '0')
{
    $pic ="chefs-1.jpg";
    $sql = "INSERT INTO `event`( `What`, `Where`, `When`, `img`,`timein`, `timeout`,  `longi`, `lati`) VALUES ('$wat','$wer','$wen','$pic','$timein','$timeout','$longitude','$latitude')";
    $res = mysqli_query($conn,$sql);
    
    if($res){
        echo "{\"res\" : \"success\"}";
    }else{
       echo "{\"res\" : \"error\"}";
    }
}
else{
    $sql = "INSERT INTO `event`( `What`, `Where`, `When`, `img`,`timein`, `timeout`,  `longi`, `lati`) VALUES ('$wat','$wer','$wen','$pic','$timein','$timeout','$longitude','$latitude')";
    $res = mysqli_query($conn,$sql);

    if($res){
        echo "{\"res\" : \"success\"}";
    }else{
       echo "{\"res\" : \"error\"}";
    }
}
    ?>