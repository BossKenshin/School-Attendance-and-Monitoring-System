<?php 
require "dbconnect.php";

$stid = $_GET['sid'];




$delete = "DELETE FROM students WHERE `stid` = '$stid'";

$result = mysqli_query($conn,$delete);

if($result){
    echo "{\"res\" : \"success\"}";
}else{
   echo "{\"res\" : \"error\"}";
}

?>