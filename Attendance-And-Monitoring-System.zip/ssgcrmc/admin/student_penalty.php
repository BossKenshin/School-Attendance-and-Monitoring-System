<?php
include "header.html"

?>
<!-- -----------------------------MODAL---------------------------- -->
        <div class="modal " id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Penalty</h5>
              </div>
              <div class="modal-body">
                <form>
                  <div class="form-group">
                    <label for="recipient-name" class="col-form-label">Penalty:</label>
                    <input type="number" class="form-control" id="penalty">
                  </div>
                </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="submit">Save Changes</button>
              </div>
            </div>
          </div>
        </div>

          <!-- --------------------------------------------------------- -->
          <?php

include './fragments/sidebar.php';
?>
  

  <section class="home-section">
    
    <nav>
      <div class="sidebar-button">
        <i class='il uil-arrow-circle-left sidebarBtn'></i>
      </div>
      <div class="profile-details">
        <i class="uil uil-user-circle"></i>
        <i class="bx bx-chevron-down" onclick="toggleMenu()"></i>

      <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
          <div class="user-info">
          <i class="uil uil-user-circle user"></i> 
          <h4>Admin Account</h4>
          <hr>
          </div>
         

          <a href="user_profile.php" class="sub-menu-link">
          <i class="il uil-user-square usermenu"></i>
          <p>Profile</p>
          </a>
          <a href="admin_logout.php" class="sub-menu-link">
          <i class="uil uil-signout usermenu"></i>
          <p>Log Out</p>
          </a>

        </div>
      </div>

      </div> 
    </nav>

  

    <div class="home-content">
 
 <div class="overview-boxes">
  
   <div class="con">          
           <i class="uil uil-sign-alt"></i>
           <h3>Student Penalty Information</h3>
         <div class="sat" style="display: flex;justify-content:right;width:1000px; font-size: 13px; max-height:100vh"> 
         <div class="sat" style="display: flex;justify-content:left;width:1000px; font-size: 13px; max-height:100vh"> 
          <button type="button" id="penal" class="btn btn-success uil uil-plus" data-toggle="modal" data-target="#exampleModal" style="  background-color: #66db93;color:black"><a href="#" style="Color:black; text-decoration: none">Add Penalty</a></button>
          </div>
                  <label>Events</label>
                <select name="category_id" class="custom-select browser-default" id="loadevent">
                      <template id="eventsload">
                                <option id="idevent">
                                </option> 
                              </template>  
				        </select>

                </div>
                
</div>
            <div class="containers py-5" style="width:1300px; height:600px; font-size: 13px; overflow-y: scroll; overflow-x:scroll; max-height:100vh">
            <div class="row">

          <table id="example" class="table table-striped" style="width:100%">
         
          

          <thead style="color: black">
          
            <tr>
                <th style="text-align: center"><b>ID</b></th>
                <th style="text-align: center"><b>STUDENT NAME</b></th>
                <th style="text-align: center"><b>Event</b></th>
                <th style="text-align: center"><b>Date</b></th>
            </tr>
        </thead>
        <tbody>
          <style>
            td{
              text-align: left;
            }
          </style>
       
          </thead>
      </table>
    </div>
</div>
    </div>  
  </section>


  <script>
    loadevents();
 
    function loadevents(){
           
           $.ajax({
               url : "sql/event.load.php"
           })
           .done(function(data){
               let result = JSON.parse(data);
               
               var template = document.querySelector("#eventsload");
               var parent = document.querySelector("#loadevent");
               parent.innerHTML = "";

               result.forEach(item => {
                   let clone = template.content.cloneNode(true);

                   clone.querySelector("option").innerHTML = item.What;
                  clone.querySelector("option").setAttribute("value",item.Id);
                parent.append(clone);
               });
           });

       }
       $("#loadevent").change(function () {
$("#loadevent option:selected").each(function () {
  var eid = $(this).val();

  $('#example').DataTable().destroy();
  seteventTable();
  function seteventTable() {
    
                $.ajax({
                    url: "sql/events.student.php",
                    type : "GET",
                    data :  {
                      Id : eid,
               
                    },

success: function (data) {
var deptData = JSON.parse(data);

$("#example").DataTable({
  data: deptData,
  columns: [
    { data: "student_id_no" },
    { data: "Name" },
    { data: "What" },
    { data: "When" },
  ],
});

},

});
}

});
})
.change();

$("#submit").on('click',function(){

  Swal.fire({ title: 'Do you really want to Add this Penalty?', showDenyButton: true,  confirmButtonText: 'Yes', denyButtonText: `No`, }).then((result) => {
  if (result.isConfirmed) {
var eid = $("#loadevent option:selected").val();
var penalty = document.querySelector("#penalty").value;

                $.ajax({
                    url  : "sql/add.penalty.student.php",
                    type : "GET",
                    data :  {
               Penalty:penalty,
               Id:eid
                
                    }
                })
                .done(function(data){
                    let result = JSON.parse(data);
                    if(result.res == "success"){
                      Swal.fire('Penalty is successfully added!', '', 'success');
                                              $.ajax({
                                            url  : "sql/update.event.status.php",
                                            type : "GET",
                                            data :  {
                                              Id : eid
                                            }
                                        })
                                        .done(function(data){
                            let result = JSON.parse(data);
                              if(result.res == "success"){     
                               
                                  location.reload();
                                            }else{
                                  alert("Error, Something happened!!!!");
                        
                                            }
                                        });
 
                    }else{
                  
                    }

                });
          } 
              else if (result.isDenied) { 
               
                document.querySelector("form").reset();
                Swal.fire('Penalty are not saved', '', 'info') } 
        });
        });    

  </script>
  <?php
include "footer.html"

?>

