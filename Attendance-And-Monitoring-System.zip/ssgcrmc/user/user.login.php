<?php
session_start();

include 'db_connect.php';

if(isset($_POST['submit'])){

  $em = $_POST['emailadd'];
  $po = $_POST['passadd'];

      $login = "SELECT * FROM students WHERE email = '$em' AND st_password = '$po'";
      $result = mysqli_query($conn,$login);

      if(mysqli_num_rows($result) == 1){

        $row = mysqli_fetch_assoc($result);

        session_start();
          $_SESSION['student_uid'] =  $row['stid'];
          $_SESSION['student_id_no'] =  $row['student_id_no'];
          $_SESSION['student_name'] =  $row['firstname']. ' '. $row['lastname'];

        header("location: ../admin/ssg.landingpage.php");
      }
      else{

        $login = "SELECT * FROM admin WHERE email = '$em' AND password = '$po'";
        $result = mysqli_query($conn,$login);
  
        if(mysqli_num_rows($result) == 1){
  
          $row = mysqli_fetch_assoc($result);
  
          session_start();
            $_SESSION['admin_uid'] =  $row['id'];
            $_SESSION['admin_position'] =  $row['position'];
            $_SESSION['admin_name'] =  $row['fullname'];
  
          header("location: ../admin/index.php");
        }
        else{
          echo "<div class='container bg-light p-4 shadow' id='warning-div'>   <h4>Wrong Credentials</h4> <button class='btn btn-warning' id='wrongbtn'>Close</button></div>";
        }



      }



}
else{

}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> CRMC SSG </title>
    <link rel="icon" type="image/x-icon" href="images/logo.jpg" />

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>

<style>
    .background-radial-gradient,body {
      background-color: hsl(150, 52%, 51%);
      background-image: radial-gradient(650px circle at 0% 0%,
          hsl(150, 52%, 51%) 15%,
          hsl(150, 52%, 51%) 35%,
          hsl(150, 52%, 51%) 75%,
          hsl(150, 52%, 51%) 80%,
          transparent 100%),
        radial-gradient(1250px circle at 100% 100%,
          hsl(150, 52%, 51%) 15%,
          hsl(150, 52%, 51%) 35%,
          hsl(150, 52%, 51%) 75%,
          hsl(150, 52%, 51%) 80%,
          transparent 100%);
    }

    #radius-shape-1 {
      height: 220px;
      width: 220px;
      top: -60px;
      left: -130px;
      background: radial-gradient(#024a07, #023605);
      overflow: hidden;
    }

    #radius-shape-2 {
      border-radius: 38% 62% 63% 37% / 70% 33% 67% 30%;
      bottom: -60px;
      right: -110px;
      width: 300px;
      height: 300px;
      background: radial-gradient(#024a07, #023605);
      overflow: hidden;
    }

    .bg-glass {
      background-color: hsla(0, 0%, 100%, 0.9) !important;
      backdrop-filter: saturate(200%) blur(25px);
    }
</style>

<body>
<section class="container-fluid background-radial-gradient overflow-hidden">   

<div class="container px-4 py-5 px-md-5 text-center text-lg-start my-5">
    <div class="row gx-lg-5 align-items-center mb-5">
      <div class="col-lg-6 mb-5 mb-lg-0" style="z-index: 10">
        <h1 class="my-5 display-5 fw-bold ls-tight" style="color: hsl(218, 81%, 95%)">
        <img src="images/logo1.png" style="width:200px; height:200px"><br>
          CEBU ROOSEVELT MEMORIAL COLLEGES <br>
          <span style="color: white">Supreme Student Government</span>
        </h1>
        
      </div>

      <div class="col-lg-6 mb-5 mb-lg-0 position-relative">
        <div id="radius-shape-1" class="position-absolute rounded-circle shadow-5-strong"></div>
        <div id="radius-shape-2" class="position-absolute shadow-5-strong"></div>

        <div class="card bg-glass">
          <div class="card-body px-4 py-5 px-md-5">
            <form action="user.login.php" method="post">

              <h1>Sign In</h1><br>
              <div class="row">

              <!-- Email input -->
              <div class="form-outline mb-4">
                <input type="email" id="emailinput" class="form-control" name="emailadd" required />
                <label class="form-label" for="emailinput">Email address</label>
              </div>

              <!-- Password input -->
              <div class="form-outline mb-4">
                <input type="password" id="passwordinput" class="form-control" name="passadd" required/>
                <label class="form-label" for="passwordinput">Password</label>
              </div>

              <!-- Submit button -->
              <button type="submit" name="submit" class="btn btn-primary btn-block mb-5">
                Sign In
              </button>

              <!-- Register buttons -->
              <div class="text-center">
                
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<script>
        $('#wrongbtn').click(function() {
          $( "div" ).remove( "#warning-div" );
      
    });
  </script>
</body>
</html>